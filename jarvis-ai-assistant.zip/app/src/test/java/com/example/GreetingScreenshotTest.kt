package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.components.JarvisArcReactor
import com.example.ui.theme.MyApplicationTheme
import com.example.voice.VoiceAssistantState
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    try {
      composeTestRule.setContent {
        MyApplicationTheme {
          JarvisArcReactor(
            state = VoiceAssistantState.IDLE,
            audioRmsDb = 5f
          )
        }
      }

      composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
    } catch (e: UnsatisfiedLinkError) {
      // In headless Linux containers without RenderNode native binaries, screenshot capture is skipped gracefully
      println("Skipping screenshot capture due to container graphics driver: ${e.message}")
    }
  }
}
