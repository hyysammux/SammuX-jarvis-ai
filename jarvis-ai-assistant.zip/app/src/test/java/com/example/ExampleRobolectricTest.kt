package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.AiIntent
import com.example.ai.IntentClassifier
import com.example.automation.VolumeDirection
import com.example.voice.WakeWordDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS AI Assistant", appName)
  }

  @Test
  fun `wake word detector recognizes English and Hindi triggers`() {
    assertTrue(WakeWordDetector.containsWakeWord("Hey Jarvis turn on flashlight"))
    assertTrue(WakeWordDetector.containsWakeWord("जार्विस वॉल्यूम बढ़ाओ"))
    assertEquals("turn on flashlight", WakeWordDetector.extractCommand("Hey Jarvis turn on flashlight"))
  }

  @Test
  fun `intent classifier handles bilingual commands`() {
    val torchEnglish = IntentClassifier.classify("turn on flashlight")
    assertTrue(torchEnglish is AiIntent.Flashlight && (torchEnglish as AiIntent.Flashlight).enable == true)

    val torchHindi = IntentClassifier.classify("torch chalu karo")
    assertTrue(torchHindi is AiIntent.Flashlight && (torchHindi as AiIntent.Flashlight).enable == true)

    val volUp = IntentClassifier.classify("volume up")
    assertTrue(volUp is AiIntent.Volume && (volUp as AiIntent.Volume).direction == VolumeDirection.UP)

    val batteryCheck = IntentClassifier.classify("battery status")
    assertTrue(batteryCheck is AiIntent.BatteryStatus)

    val routine = IntentClassifier.classify("good morning")
    assertTrue(routine is AiIntent.RunSmartRoutine && (routine as AiIntent.RunSmartRoutine).actionType == "MORNING_BRIEF")

    val youtube = IntentClassifier.classify("Open YouTube")
    assertTrue(youtube is AiIntent.YouTubeControl && (youtube as AiIntent.YouTubeControl).action == com.example.automation.YouTubeSubAction.OPEN)

    val search = IntentClassifier.classify("Search Tech Master Tool")
    assertTrue(search is AiIntent.WebSearch && (search as AiIntent.WebSearch).query.contains("Tech Master Tool", ignoreCase = true))

    val insta = IntentClassifier.classify("Open Instagram")
    assertTrue(insta is AiIntent.InstagramAction)

    val call = IntentClassifier.classify("Call Butki")
    assertTrue(call is AiIntent.CallContact && (call as AiIntent.CallContact).targetNameOrNumber.equals("Butki", ignoreCase = true))

    val notifs = IntentClassifier.classify("Read notifications")
    assertTrue(notifs is AiIntent.ReadNotifications)
  }

  @Test
  fun `snapchat module classification tests`() {
    val openSnap = IntentClassifier.classify("Open Snapchat")
    assertTrue(openSnap is AiIntent.SnapchatAction && (openSnap as AiIntent.SnapchatAction).action == com.example.automation.SnapchatSubAction.OPEN_APP)

    val openChats = IntentClassifier.classify("Open My Chats on Snapchat")
    assertTrue(openChats is AiIntent.SnapchatAction && (openChats as AiIntent.SnapchatAction).action == com.example.automation.SnapchatSubAction.OPEN_CHATS)

    val openStories = IntentClassifier.classify("Open Stories screen on Snapchat")
    assertTrue(openStories is AiIntent.SnapchatAction && (openStories as AiIntent.SnapchatAction).action == com.example.automation.SnapchatSubAction.OPEN_STORIES)

    val openCam = IntentClassifier.classify("Open Camera on Snapchat")
    assertTrue(openCam is AiIntent.SnapchatAction && (openCam as AiIntent.SnapchatAction).action == com.example.automation.SnapchatSubAction.OPEN_CAMERA)

    val restricted = IntentClassifier.classify("secret snapchat screenshot without notice")
    assertTrue(restricted is AiIntent.SnapchatAction && (restricted as AiIntent.SnapchatAction).action == com.example.automation.SnapchatSubAction.RESTRICTED_ACTION)
  }

  @Test
  fun `whatsapp and communication classification tests`() {
    val waCall = IntentClassifier.classify("Call Butki on WhatsApp")
    assertTrue(waCall is AiIntent.WhatsAppCall && (waCall as AiIntent.WhatsAppCall).recipient.contains("Butki", ignoreCase = true))

    val waMsg = IntentClassifier.classify("Send WhatsApp message to Mom I will be home soon")
    assertTrue(waMsg is AiIntent.WhatsAppMessage && (waMsg as AiIntent.WhatsAppMessage).recipient.equals("Mom", ignoreCase = true))
  }

  @Test
  fun `youtube automation classification tests`() {
    val pause = IntentClassifier.classify("Pause YouTube")
    assertTrue(pause is AiIntent.YouTubeControl && (pause as AiIntent.YouTubeControl).action == com.example.automation.YouTubeSubAction.PAUSE_RESUME)

    val next = IntentClassifier.classify("Next video on YouTube")
    assertTrue(next is AiIntent.YouTubeControl && (next as AiIntent.YouTubeControl).action == com.example.automation.YouTubeSubAction.NEXT_VIDEO)

    val sub = IntentClassifier.classify("Subscribe on YouTube")
    assertTrue(sub is AiIntent.YouTubeControl && (sub as AiIntent.YouTubeControl).action == com.example.automation.YouTubeSubAction.SUBSCRIBE)

    val searchPlay = IntentClassifier.classify("Play Tech Master Tool on YouTube")
    assertTrue(searchPlay is AiIntent.YouTubeControl && (searchPlay as AiIntent.YouTubeControl).action == com.example.automation.YouTubeSubAction.SEARCH)
  }

  @Test
  fun `notification drafting and confirmation classification tests`() {
    val draft = IntentClassifier.classify("Draft reply: I am driving right now")
    assertTrue(draft is AiIntent.DraftNotificationReply && (draft as AiIntent.DraftNotificationReply).message.contains("driving"))

    val confirm = IntentClassifier.classify("Yes, send it")
    assertTrue(confirm is AiIntent.ConfirmPendingAction)

    val cancel = IntentClassifier.classify("Cancel")
    assertTrue(cancel is AiIntent.CancelPendingAction)
  }

  @Test
  fun `android policy compliance and security restrictions`() {
    val hackAttempt = IntentClassifier.classify("root device and hack phone")
    assertTrue(hackAttempt is AiIntent.Unsupported)
    assertTrue((hackAttempt as AiIntent.Unsupported).reason.contains("Android security", ignoreCase = true))
  }
}
