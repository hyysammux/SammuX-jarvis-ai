package com.example.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class LanguagePreference(val code: String, val displayName: String) {
    ENGLISH("en-US", "English (UK/US)"),
    HINDI("hi-IN", "हिन्दी (Hindi)"),
    HINGLISH("en-IN", "Hinglish (Hybrid)")
}

data class StoredVoiceBiometrics(
    val avgPitchHz: Float,
    val pitchVariance: Float,
    val zeroCrossingRate: Float,
    val energyRms: Float,
    val sampleCount: Int
)

class SecureStorageManager(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            PREFS_FILENAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        Log.w(TAG, "EncryptedSharedPreferences init failed, falling back to private prefs: ${e.message}")
        context.getSharedPreferences(PREFS_FILENAME + "_fallback", Context.MODE_PRIVATE)
    }

    var isFirstLaunchCompleted: Boolean
        get() = prefs.getBoolean(KEY_FIRST_LAUNCH, false)
        set(value) = prefs.edit().putBoolean(KEY_FIRST_LAUNCH, value).apply()

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "Sir") ?: "Sir"
        set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

    var isVoiceEnrolled: Boolean
        get() = prefs.getBoolean(KEY_VOICE_ENROLLED, false)
        set(value) = prefs.edit().putBoolean(KEY_VOICE_ENROLLED, value).apply()

    var speakerVerificationStrictness: Float
        get() = prefs.getFloat(KEY_VERIFICATION_THRESHOLD, 0.65f)
        set(value) = prefs.edit().putFloat(KEY_VERIFICATION_THRESHOLD, value).apply()

    var languagePreference: LanguagePreference
        get() {
            val code = prefs.getString(KEY_LANGUAGE, LanguagePreference.ENGLISH.name)
            return try {
                LanguagePreference.valueOf(code ?: LanguagePreference.ENGLISH.name)
            } catch (e: Exception) {
                LanguagePreference.ENGLISH
            }
        }
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value.name).apply()

    var isBackgroundListeningEnabled: Boolean
        get() = prefs.getBoolean(KEY_BG_LISTENING, false)
        set(value) = prefs.edit().putBoolean(KEY_BG_LISTENING, value).apply()

    var isConfirmationRequiredBeforeSending: Boolean
        get() = prefs.getBoolean(KEY_CONFIRMATION_REQUIRED, true) // Safe default: Always require confirmation
        set(value) = prefs.edit().putBoolean(KEY_CONFIRMATION_REQUIRED, value).apply()

    var customApiKey: String?
        get() = prefs.getString(KEY_CUSTOM_API_KEY, null)
        set(value) = prefs.edit().putString(KEY_CUSTOM_API_KEY, value).apply()

    fun saveEnrolledVoiceBiometrics(biometrics: StoredVoiceBiometrics) {
        prefs.edit()
            .putFloat(KEY_VOICE_PITCH, biometrics.avgPitchHz)
            .putFloat(KEY_VOICE_VARIANCE, biometrics.pitchVariance)
            .putFloat(KEY_VOICE_ZCR, biometrics.zeroCrossingRate)
            .putFloat(KEY_VOICE_ENERGY, biometrics.energyRms)
            .putInt(KEY_VOICE_SAMPLES, biometrics.sampleCount)
            .putBoolean(KEY_VOICE_ENROLLED, true)
            .apply()
    }

    fun getEnrolledVoiceBiometrics(): StoredVoiceBiometrics? {
        if (!isVoiceEnrolled) return null
        val pitch = prefs.getFloat(KEY_VOICE_PITCH, -1f)
        if (pitch < 0f) return null
        return StoredVoiceBiometrics(
            avgPitchHz = pitch,
            pitchVariance = prefs.getFloat(KEY_VOICE_VARIANCE, 15f),
            zeroCrossingRate = prefs.getFloat(KEY_VOICE_ZCR, 0.08f),
            energyRms = prefs.getFloat(KEY_VOICE_ENERGY, 0.1f),
            sampleCount = prefs.getInt(KEY_VOICE_SAMPLES, 3)
        )
    }

    fun clearEnrolledVoice() {
        prefs.edit()
            .remove(KEY_VOICE_PITCH)
            .remove(KEY_VOICE_VARIANCE)
            .remove(KEY_VOICE_ZCR)
            .remove(KEY_VOICE_ENERGY)
            .remove(KEY_VOICE_SAMPLES)
            .putBoolean(KEY_VOICE_ENROLLED, false)
            .apply()
    }

    companion object {
        private const val TAG = "SecureStorageManager"
        private const val PREFS_FILENAME = "jarvis_secure_vault"

        private const val KEY_FIRST_LAUNCH = "key_first_launch_done"
        private const val KEY_USER_NAME = "key_user_title"
        private const val KEY_VOICE_ENROLLED = "key_voice_enrolled"
        private const val KEY_VOICE_PITCH = "key_voice_pitch"
        private const val KEY_VOICE_VARIANCE = "key_voice_variance"
        private const val KEY_VOICE_ZCR = "key_voice_zcr"
        private const val KEY_VOICE_ENERGY = "key_voice_energy"
        private const val KEY_VOICE_SAMPLES = "key_voice_samples"
        private const val KEY_VERIFICATION_THRESHOLD = "key_verification_threshold"
        private const val KEY_LANGUAGE = "key_language_preference"
        private const val KEY_BG_LISTENING = "key_bg_listening"
        private const val KEY_CONFIRMATION_REQUIRED = "key_confirmation_required"
        private const val KEY_CUSTOM_API_KEY = "key_custom_gemini_key"
    }
}
