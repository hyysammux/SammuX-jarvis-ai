package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.JarvisMainViewModel
import com.example.ui.JarvisScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.RoutinesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.VoiceEnrollmentScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldDark
import com.example.ui.theme.JarvisSurfaceCard
import com.example.ui.theme.JarvisTextSecondary
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                JarvisAppContent()
            }
        }
    }
}

@Composable
fun JarvisAppContent(viewModel: JarvisMainViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val recentLogs by viewModel.recentLogs.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val allRoutines by viewModel.allRoutines.collectAsState()

    val showBottomBar = uiState.currentScreen in listOf(
        JarvisScreen.HOME,
        JarvisScreen.ROUTINES,
        JarvisScreen.NOTES
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack),
        contentWindowInsets = WindowInsets.systemBars,
        bottomBar = {
            if (showBottomBar) {
                JarvisNavigationBar(
                    currentScreen = uiState.currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = uiState.currentScreen,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            label = "screen_transition"
        ) { screen ->
            when (screen) {
                JarvisScreen.SPLASH -> {
                    SplashScreen(
                        isFirstLaunchCompleted = uiState.isJarvisReady,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }

                JarvisScreen.WELCOME -> {
                    WelcomeScreen(
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }

                JarvisScreen.PERMISSIONS -> {
                    PermissionsScreen(
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }

                JarvisScreen.VOICE_ENROLLMENT -> {
                    VoiceEnrollmentScreen(
                        viewModel = viewModel,
                        step = uiState.enrollmentStep,
                        isRecording = uiState.isEnrolling,
                        amplitude = uiState.enrollmentAmplitude
                    )
                }

                JarvisScreen.HOME -> {
                    HomeScreen(
                        uiState = uiState,
                        recentLogs = recentLogs,
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }

                JarvisScreen.ROUTINES -> {
                    RoutinesScreen(
                        routines = allRoutines,
                        viewModel = viewModel
                    )
                }

                JarvisScreen.NOTES -> {
                    NotesScreen(
                        notes = allNotes,
                        viewModel = viewModel
                    )
                }

                JarvisScreen.SETTINGS -> {
                    SettingsScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onNavigateBack = { viewModel.navigateTo(JarvisScreen.HOME) }
                    )
                }
            }
        }
    }
}

@Composable
fun JarvisNavigationBar(
    currentScreen: JarvisScreen,
    onNavigate: (JarvisScreen) -> Unit
) {
    NavigationBar(
        containerColor = JarvisBlack,
        tonalElevation = 0.dp
    ) {
        NavigationBarItem(
            selected = currentScreen == JarvisScreen.HOME,
            onClick = { onNavigate(JarvisScreen.HOME) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Core HUD",
                    modifier = Modifier.size(22.dp)
                )
            },
            label = {
                Text(
                    text = "CORE HUD",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = JarvisGoldBright,
                selectedTextColor = JarvisGoldBright,
                indicatorColor = JarvisSurfaceCard,
                unselectedIconColor = JarvisGoldDark,
                unselectedTextColor = JarvisTextSecondary
            )
        )

        NavigationBarItem(
            selected = currentScreen == JarvisScreen.ROUTINES,
            onClick = { onNavigate(JarvisScreen.ROUTINES) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Protocols",
                    modifier = Modifier.size(22.dp)
                )
            },
            label = {
                Text(
                    text = "PROTOCOLS",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = JarvisGoldBright,
                selectedTextColor = JarvisGoldBright,
                indicatorColor = JarvisSurfaceCard,
                unselectedIconColor = JarvisGoldDark,
                unselectedTextColor = JarvisTextSecondary
            )
        )

        NavigationBarItem(
            selected = currentScreen == JarvisScreen.NOTES,
            onClick = { onNavigate(JarvisScreen.NOTES) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Description,
                    contentDescription = "Vault",
                    modifier = Modifier.size(22.dp)
                )
            },
            label = {
                Text(
                    text = "VAULT",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = JarvisGoldBright,
                selectedTextColor = JarvisGoldBright,
                indicatorColor = JarvisSurfaceCard,
                unselectedIconColor = JarvisGoldDark,
                unselectedTextColor = JarvisTextSecondary
            )
        )
    }
}
