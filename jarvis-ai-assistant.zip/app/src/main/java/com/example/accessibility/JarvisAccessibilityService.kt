package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Passive observation only - respects user privacy
    }

    override fun onInterrupt() {
        // Handle interruption
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
    }

    companion object {
        private var instance: JarvisAccessibilityService? = null

        fun isServiceRunning(): Boolean = instance != null

        fun goBack(): Boolean = instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun goHome(): Boolean = instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        fun showRecents(): Boolean = instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false
        fun showNotifications(): Boolean = instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false
        fun showQuickSettings(): Boolean = instance?.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) ?: false

        fun findAndClickByText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            return try {
                val nodes = root.findAccessibilityNodeInfosByText(text)
                var clicked = false
                for (node in nodes) {
                    if (node.isClickable) {
                        node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                        clicked = true
                        break
                    } else {
                        var parent = node.parent
                        while (parent != null) {
                            if (parent.isClickable) {
                                parent.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                                clicked = true
                                break
                            }
                            parent = parent.parent
                        }
                        if (clicked) break
                    }
                }
                clicked
            } catch (e: Exception) {
                false
            }
        }

        fun findAndClickByContentDescription(desc: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            return try {
                fun searchNode(node: android.view.accessibility.AccessibilityNodeInfo): Boolean {
                    val contentDesc = node.contentDescription?.toString().orEmpty()
                    if (contentDesc.contains(desc, ignoreCase = true)) {
                        if (node.isClickable) {
                            node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                            return true
                        }
                        var parent = node.parent
                        while (parent != null) {
                            if (parent.isClickable) {
                                parent.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                                return true
                            }
                            parent = parent.parent
                        }
                    }
                    for (i in 0 until node.childCount) {
                        val child = node.getChild(i) ?: continue
                        if (searchNode(child)) return true
                    }
                    return false
                }
                searchNode(root)
            } catch (e: Exception) {
                false
            }
        }

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
