package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "command_logs")
data class CommandLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val rawQuery: String,
    val isSpeakerVerified: Boolean,
    val matchConfidence: Float,
    val intentType: String,
    val responseText: String,
    val isSuccess: Boolean
)

@Entity(tableName = "jarvis_notes")
data class JarvisNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val content: String,
    val category: String = "General"
)

@Entity(tableName = "smart_routines")
data class SmartRoutineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val routineName: String,
    val triggerPhrase: String,
    val actionType: String,
    val actionPayload: String,
    val isEnabled: Boolean = true,
    val description: String = ""
)
