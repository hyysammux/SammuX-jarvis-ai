package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface JarvisDao {

    // Command Logs
    @Query("SELECT * FROM command_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentCommandLogs(): Flow<List<CommandLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommandLog(log: CommandLogEntity): Long

    @Query("DELETE FROM command_logs")
    suspend fun clearAllLogs()

    // Notes & Reminders
    @Query("SELECT * FROM jarvis_notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<JarvisNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: JarvisNoteEntity): Long

    @Query("DELETE FROM jarvis_notes WHERE id = :noteId")
    suspend fun deleteNoteById(noteId: Long)

    // Smart Automation Routines
    @Query("SELECT * FROM smart_routines ORDER BY id ASC")
    fun getAllRoutines(): Flow<List<SmartRoutineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutines(routines: List<SmartRoutineEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(routine: SmartRoutineEntity): Long

    @Update
    suspend fun updateRoutine(routine: SmartRoutineEntity)

    @Query("SELECT COUNT(*) FROM smart_routines")
    suspend fun getRoutinesCount(): Int
}
