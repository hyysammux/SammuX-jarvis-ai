package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class JarvisRepository(private val dao: JarvisDao) {

    val recentCommandLogs: Flow<List<CommandLogEntity>> = dao.getRecentCommandLogs()
    val allNotes: Flow<List<JarvisNoteEntity>> = dao.getAllNotes()
    val allRoutines: Flow<List<SmartRoutineEntity>> = dao.getAllRoutines()

    suspend fun logCommand(
        rawQuery: String,
        isSpeakerVerified: Boolean,
        matchConfidence: Float,
        intentType: String,
        responseText: String,
        isSuccess: Boolean
    ): Long = withContext(Dispatchers.IO) {
        dao.insertCommandLog(
            CommandLogEntity(
                rawQuery = rawQuery,
                isSpeakerVerified = isSpeakerVerified,
                matchConfidence = matchConfidence,
                intentType = intentType,
                responseText = responseText,
                isSuccess = isSuccess
            )
        )
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        dao.clearAllLogs()
    }

    suspend fun saveNote(title: String, content: String, category: String = "General"): Long =
        withContext(Dispatchers.IO) {
            dao.insertNote(
                JarvisNoteEntity(
                    title = title,
                    content = content,
                    category = category
                )
            )
        }

    suspend fun deleteNote(noteId: Long) = withContext(Dispatchers.IO) {
        dao.deleteNoteById(noteId)
    }

    suspend fun toggleRoutine(routine: SmartRoutineEntity) = withContext(Dispatchers.IO) {
        dao.updateRoutine(routine.copy(isEnabled = !routine.isEnabled))
    }

    suspend fun ensureDefaultRoutines() = withContext(Dispatchers.IO) {
        if (dao.getRoutinesCount() == 0) {
            val defaults = listOf(
                SmartRoutineEntity(
                    routineName = "Morning Protocol",
                    triggerPhrase = "Good morning Jarvis",
                    actionType = "MORNING_BRIEF",
                    actionPayload = "time,battery,notes",
                    description = "Announces time, battery health, and pending notes."
                ),
                SmartRoutineEntity(
                    routineName = "Focus Protocol",
                    triggerPhrase = "Activate focus mode",
                    actionType = "FOCUS_MODE",
                    actionPayload = "mute,lock",
                    description = "Mutes device media and prepares focus state."
                ),
                SmartRoutineEntity(
                    routineName = "Diagnostics & Security",
                    triggerPhrase = "Run system diagnostics",
                    actionType = "SECURITY_CHECK",
                    actionPayload = "security,battery",
                    description = "Performs biometric vault verification and hardware check."
                ),
                SmartRoutineEntity(
                    routineName = "Night Protocol",
                    triggerPhrase = "Good night Jarvis",
                    actionType = "NIGHT_MODE",
                    actionPayload = "mute,flashlight_off",
                    description = "Powers off flashlight, silences audio, and bids good night."
                )
            )
            dao.insertRoutines(defaults)
        }
    }
}
