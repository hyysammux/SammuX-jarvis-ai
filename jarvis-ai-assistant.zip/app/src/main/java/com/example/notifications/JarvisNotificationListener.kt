package com.example.notifications

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

data class CapturedNotification(
    val id: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val hasDirectReply: Boolean = false,
    val replyActionIndex: Int = -1,
    val notificationKey: String = ""
)

class JarvisNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        isServiceActive = true
        Log.d(TAG, "Notification listener connected")
        refreshActiveNotifications()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) instance = null
        isServiceActive = false
        Log.d(TAG, "Notification listener disconnected")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
        isServiceActive = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null || sbn.packageName == packageName) return
        extractAndStoreNotification(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        if (sbn == null) return
        val notifId = "${sbn.packageName}_${sbn.id}"
        synchronized(notificationCache) {
            notificationCache.removeAll { it.id == notifId }
        }
    }

    private fun extractAndStoreNotification(sbn: StatusBarNotification) {
        try {
            val extras = sbn.notification.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()

            if (title.isBlank() && text.isBlank()) return

            val pm = packageManager
            val appLabel = try {
                val appInfo = pm.getApplicationInfo(sbn.packageName, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                sbn.packageName.substringAfterLast('.')
            }

            var hasReply = false
            var replyIndex = -1
            sbn.notification.actions?.forEachIndexed { index, action ->
                if (action.remoteInputs != null && action.remoteInputs.isNotEmpty()) {
                    hasReply = true
                    replyIndex = index
                }
            }

            val notif = CapturedNotification(
                id = "${sbn.packageName}_${sbn.id}",
                packageName = sbn.packageName,
                appName = appLabel,
                title = title,
                text = text,
                timestamp = sbn.postTime,
                hasDirectReply = hasReply,
                replyActionIndex = replyIndex,
                notificationKey = sbn.key
            )

            synchronized(notificationCache) {
                notificationCache.removeAll { it.id == notif.id }
                notificationCache.add(0, notif)
                if (notificationCache.size > MAX_STORED) {
                    notificationCache.removeAt(notificationCache.size - 1)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting notification: ${e.message}")
        }
    }

    private fun refreshActiveNotifications() {
        try {
            val active = activeNotifications ?: return
            for (sbn in active) {
                if (sbn.packageName != packageName) {
                    extractAndStoreNotification(sbn)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing active notifications: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "JarvisNotificationList"
        private const val MAX_STORED = 12
        private val notificationCache = mutableListOf<CapturedNotification>()
        private var instance: JarvisNotificationListener? = null

        var isServiceActive: Boolean = false
            private set

        fun sendInlineReply(context: Context, notificationKey: String, replyText: String): Boolean {
            val service = instance ?: return false
            return try {
                val active = service.activeNotifications ?: return false
                val targetSbn = active.firstOrNull { it.key == notificationKey } ?: return false
                val actions = targetSbn.notification.actions ?: return false

                var dispatched = false
                for (action in actions) {
                    val remoteInputs = action.remoteInputs
                    if (!remoteInputs.isNullOrEmpty()) {
                        val input = remoteInputs[0]
                        val intent = Intent()
                        val bundle = android.os.Bundle()
                        bundle.putCharSequence(input.resultKey, replyText)
                        android.app.RemoteInput.addResultsToIntent(arrayOf(input), intent, bundle)
                        action.actionIntent.send(context, 0, intent)
                        dispatched = true
                        break
                    }
                }
                dispatched
            } catch (e: Exception) {
                Log.e(TAG, "Failed to send inline reply: ${e.message}", e)
                false
            }
        }

        fun isNotificationAccessGranted(context: Context): Boolean {
            val componentName = ComponentName(context, JarvisNotificationListener::class.java)
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            return flat != null && flat.contains(componentName.flattenToString())
        }

        fun openNotificationAccessSettings(context: Context) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }

        fun getRecentNotifications(): List<CapturedNotification> {
            return synchronized(notificationCache) {
                notificationCache.toList()
            }
        }

        fun formatNotificationsForSpeech(context: Context): String {
            if (!isNotificationAccessGranted(context)) {
                return "Notification access is not enabled in system settings, Sir. Please grant Notification Listener access to allow me to read your alerts."
            }

            val list = getRecentNotifications()
            if (list.isEmpty()) {
                return "You have no unread notifications in your telemetry feed, Sir."
            }

            val count = list.size
            val sb = StringBuilder()
            sb.append("You have $count active notifications, Sir. ")

            // Read the top 3 notifications clearly
            val toRead = list.take(3)
            toRead.forEachIndexed { index, item ->
                val titlePart = if (item.title.isNotBlank()) "from ${item.title}" else ""
                val textPart = if (item.text.isNotBlank()) ": '${item.text}'" else ""
                sb.append("Notice ${index + 1}: ${item.appName} $titlePart$textPart. ")
            }

            if (list.size > 3) {
                sb.append("Plus ${list.size - 3} more notifications available in your vault.")
            }

            return sb.toString().trim()
        }
    }
}
