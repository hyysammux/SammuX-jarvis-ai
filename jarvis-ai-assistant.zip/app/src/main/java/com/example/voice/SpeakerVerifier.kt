package com.example.voice

import com.example.security.LanguagePreference
import com.example.security.SecureStorageManager
import com.example.security.StoredVoiceBiometrics
import kotlin.math.abs

class SpeakerVerifier(private val secureStorage: SecureStorageManager) {

    /**
     * Verifies if the incoming audio features correspond to the enrolled speaker profile.
     */
    fun verify(incomingFeatures: AudioFeatures): SpeakerVerificationResult {
        val enrolled = secureStorage.getEnrolledVoiceBiometrics()

        // If no voice is enrolled yet, default to requiring enrollment
        if (enrolled == null) {
            return SpeakerVerificationResult(
                isMatch = false,
                confidence = 0f,
                feedbackMessage = "Voice profile not yet enrolled. Please complete voice enrollment in settings."
            )
        }

        val threshold = secureStorage.speakerVerificationStrictness
        val confidence = computeSimilarityScore(incomingFeatures, enrolled)
        val isMatch = confidence >= threshold

        val feedback = if (isMatch) {
            getMatchConfirmationPhrase(secureStorage.languagePreference)
        } else {
            "Voice not recognized"
        }

        return SpeakerVerificationResult(
            isMatch = isMatch,
            confidence = confidence,
            feedbackMessage = feedback
        )
    }

    private fun computeSimilarityScore(
        incoming: AudioFeatures,
        enrolled: StoredVoiceBiometrics
    ): Float {
        // Pitch difference penalty (typical tolerance +/- 35 Hz)
        val pitchDiff = abs(incoming.pitchHz - enrolled.avgPitchHz)
        val pitchScore = (1f - (pitchDiff / 65f)).coerceIn(0f, 1f)

        // Zero-crossing rate difference penalty
        val zcrDiff = abs(incoming.zeroCrossingRate - enrolled.zeroCrossingRate)
        val zcrScore = (1f - (zcrDiff / 0.15f)).coerceIn(0f, 1f)

        // Energy ratio check
        val energyScore = if (incoming.energyRms > 0.01f) 0.95f else 0.4f

        // Weighted confidence score
        val totalConfidence = (pitchScore * 0.55f) + (zcrScore * 0.30f) + (energyScore * 0.15f)
        return totalConfidence.coerceIn(0f, 1f)
    }

    private fun getMatchConfirmationPhrase(language: LanguagePreference): String {
        return when (language) {
            LanguagePreference.HINDI -> "Yes Sir, I'm listening." // Or bilingual JARVIS tone: "Yes Sir, I'm listening."
            LanguagePreference.HINGLISH -> "Yes Sir, I'm listening."
            LanguagePreference.ENGLISH -> "Yes Sir, I'm listening."
        }
    }
}
