package com.example.voice

data class AudioFeatures(
    val pitchHz: Float,
    val energyRms: Float,
    val zeroCrossingRate: Float
)

data class SpeakerVerificationResult(
    val isMatch: Boolean,
    val confidence: Float,
    val feedbackMessage: String
)

enum class VoiceAssistantState {
    IDLE,
    LISTENING_WAKE_WORD,
    WAKE_WORD_DETECTED,
    VERIFYING_SPEAKER,
    SPEAKER_VERIFIED,
    SPEAKER_REJECTED,
    LISTENING_FOR_COMMAND,
    PROCESSING_COMMAND,
    SPEAKING_RESPONSE,
    ERROR
}

data class VoiceEnrollmentPrompt(
    val step: Int,
    val totalSteps: Int,
    val englishText: String,
    val hindiText: String,
    val instruction: String
)
