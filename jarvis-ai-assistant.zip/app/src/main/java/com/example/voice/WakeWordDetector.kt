package com.example.voice

object WakeWordDetector {

    private val WAKE_PHRASES = listOf(
        "hey jarvis",
        "jarvis",
        "hey service",
        "hey javris",
        "हे जार्विस",
        "जार्विस",
        "ओ जार्विस",
        "सुनो जार्विस",
        "hi jarvis",
        "ok jarvis"
    )

    fun containsWakeWord(text: String): Boolean {
        val normalized = text.lowercase().trim()
        return WAKE_PHRASES.any { phrase ->
            normalized.contains(phrase)
        }
    }

    /**
     * Strips the wake phrase from the query to yield the direct command payload.
     */
    fun extractCommand(text: String): String {
        var command = text.trim()
        for (phrase in WAKE_PHRASES) {
            val idx = command.lowercase().indexOf(phrase)
            if (idx != -1) {
                val before = command.substring(0, idx)
                val after = command.substring(idx + phrase.length)
                command = (before + " " + after).trim()
            }
        }
        return command.trim().removePrefix(",").removePrefix(":").trim()
    }
}
