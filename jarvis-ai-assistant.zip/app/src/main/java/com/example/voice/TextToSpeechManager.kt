package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.security.LanguagePreference
import java.util.Locale

class TextToSpeechManager(
    private val context: Context,
    private val onInitComplete: (Boolean) -> Unit = {},
    private val onSpeakingStateChanged: (Boolean) -> Unit = {}
) {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                applySettings(LanguagePreference.ENGLISH)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onSpeakingStateChanged(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        onSpeakingStateChanged(false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onSpeakingStateChanged(false)
                    }
                })
                onInitComplete(true)
            } else {
                Log.e(TAG, "TTS Initialization failed with status $status")
                onInitComplete(false)
            }
        }
    }

    fun applySettings(language: LanguagePreference) {
        if (!isInitialized) return

        val targetLocale = when (language) {
            LanguagePreference.HINDI -> Locale("hi", "IN")
            LanguagePreference.HINGLISH -> Locale("en", "IN")
            LanguagePreference.ENGLISH -> Locale.UK // Classic JARVIS British tone
        }

        val result = tts?.setLanguage(targetLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }

        // Sleek JARVIS vocal qualities: slightly lower pitch, confident cadence
        tts?.setPitch(0.98f)
        tts?.setSpeechRate(1.02f)
    }

    fun speak(text: String, utteranceId: String = "jarvis_speech_${System.currentTimeMillis()}") {
        if (!isInitialized) {
            Log.w(TAG, "TTS not yet initialized, cannot speak: $text")
            return
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        onSpeakingStateChanged(false)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }

    companion object {
        private const val TAG = "TextToSpeechManager"
    }
}
