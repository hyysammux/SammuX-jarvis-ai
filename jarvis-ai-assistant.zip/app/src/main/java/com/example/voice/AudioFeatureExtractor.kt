package com.example.voice

import kotlin.math.abs
import kotlin.math.sqrt

object AudioFeatureExtractor {

    private const val SAMPLE_RATE = 16000 // Standard 16kHz audio sample rate
    private const val MIN_PITCH_HZ = 70f
    private const val MAX_PITCH_HZ = 350f

    /**
     * Extracts acoustic features from 16-bit PCM audio samples.
     */
    fun extractFeatures(pcmShorts: ShortArray): AudioFeatures {
        if (pcmShorts.isEmpty()) {
            return AudioFeatures(pitchHz = 140f, energyRms = 0.05f, zeroCrossingRate = 0.08f)
        }

        val energy = calculateRms(pcmShorts)
        val zcr = calculateZeroCrossingRate(pcmShorts)
        val pitch = estimatePitchAutocorrelation(pcmShorts, SAMPLE_RATE)

        return AudioFeatures(
            pitchHz = pitch,
            energyRms = energy,
            zeroCrossingRate = zcr
        )
    }

    private fun calculateRms(samples: ShortArray): Float {
        var sumSquares = 0.0
        for (sample in samples) {
            val normalized = sample.toDouble() / Short.MAX_VALUE
            sumSquares += normalized * normalized
        }
        return sqrt(sumSquares / samples.size).toFloat().coerceIn(0f, 1f)
    }

    private fun calculateZeroCrossingRate(samples: ShortArray): Float {
        if (samples.size < 2) return 0f
        var zeroCrossings = 0
        for (i in 1 until samples.size) {
            if ((samples[i] >= 0 && samples[i - 1] < 0) || (samples[i] < 0 && samples[i - 1] >= 0)) {
                zeroCrossings++
            }
        }
        return (zeroCrossings.toFloat() / (samples.size - 1)).coerceIn(0f, 1f)
    }

    private fun estimatePitchAutocorrelation(samples: ShortArray, sampleRate: Int): Float {
        val minLag = (sampleRate / MAX_PITCH_HZ).toInt()
        val maxLag = (sampleRate / MIN_PITCH_HZ).toInt().coerceAtMost(samples.size / 2)

        if (maxLag <= minLag || samples.size < maxLag * 2) {
            return 140f // Default human speech center
        }

        var bestCorrelation = 0.0
        var bestLag = -1

        for (lag in minLag..maxLag) {
            var correlation = 0.0
            val len = samples.size - lag
            for (i in 0 until len) {
                correlation += (samples[i].toDouble() * samples[i + lag].toDouble())
            }
            if (correlation > bestCorrelation) {
                bestCorrelation = correlation
                bestLag = lag
            }
        }

        return if (bestLag > 0) {
            (sampleRate.toFloat() / bestLag).coerceIn(MIN_PITCH_HZ, MAX_PITCH_HZ)
        } else {
            140f
        }
    }
}
