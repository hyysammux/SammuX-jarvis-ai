package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.security.LanguagePreference
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class SpeechEvent {
    object Ready : SpeechEvent()
    object BeginningOfSpeech : SpeechEvent()
    data class RmsChanged(val rmsDb: Float) : SpeechEvent()
    data class PartialResult(val partialText: String) : SpeechEvent()
    data class FinalResult(val text: String, val audioFeatures: AudioFeatures?) : SpeechEvent()
    data class Error(val errorCode: Int, val message: String) : SpeechEvent()
    object EndOfSpeech : SpeechEvent()
}

class SpeechRecognitionManager(
    private val context: Context,
    private val onEvent: (SpeechEvent) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var lastRecordedAudioFeatures: AudioFeatures? = null

    private val _isAvailable = MutableStateFlow(false)
    val isAvailable: StateFlow<Boolean> = _isAvailable.asStateFlow()

    init {
        val available = SpeechRecognizer.isRecognitionAvailable(context)
        _isAvailable.value = available
        if (available) {
            initRecognizer()
        }
    }

    private fun initRecognizer() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        onEvent(SpeechEvent.Ready)
                    }

                    override fun onBeginningOfSpeech() {
                        onEvent(SpeechEvent.BeginningOfSpeech)
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        onEvent(SpeechEvent.RmsChanged(rmsdB))
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {
                        // Extract features from incoming audio stream buffer if present
                        if (buffer != null && buffer.isNotEmpty()) {
                            val shorts = ShortArray(buffer.size / 2)
                            java.nio.ByteBuffer.wrap(buffer)
                                .order(java.nio.ByteOrder.LITTLE_ENDIAN)
                                .asShortBuffer()
                                .get(shorts)
                            lastRecordedAudioFeatures = AudioFeatureExtractor.extractFeatures(shorts)
                        }
                    }

                    override fun onEndOfSpeech() {
                        isListening = false
                        onEvent(SpeechEvent.EndOfSpeech)
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        val errorMsg = mapErrorCode(error)
                        Log.d(TAG, "SpeechRecognizer error: $error ($errorMsg)")
                        onEvent(SpeechEvent.Error(error, errorMsg))
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull().orEmpty()
                        onEvent(SpeechEvent.FinalResult(text, lastRecordedAudioFeatures))
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull().orEmpty()
                        if (text.isNotEmpty()) {
                            onEvent(SpeechEvent.PartialResult(text))
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize SpeechRecognizer: ${e.message}")
        }
    }

    fun startListening(language: LanguagePreference) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onEvent(SpeechEvent.Error(-1, "Speech recognition service not available on this device"))
            return
        }

        if (speechRecognizer == null) {
            initRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

            val langCode = when (language) {
                LanguagePreference.HINDI -> "hi-IN"
                LanguagePreference.HINGLISH -> "en-IN"
                LanguagePreference.ENGLISH -> "en-US"
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langCode)
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-IN", "hi-IN", "en-US"))
        }

        try {
            isListening = true
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            Log.e(TAG, "startListening error: ${e.message}")
            onEvent(SpeechEvent.Error(-2, e.message ?: "Failed to start listening"))
        }
    }

    fun stopListening() {
        if (isListening) {
            isListening = false
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.w(TAG, "stopListening exception: ${e.message}")
            }
        }
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.w(TAG, "destroy exception: ${e.message}")
        }
    }

    private fun mapErrorCode(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
            SpeechRecognizer.ERROR_CLIENT -> "Client error"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
            SpeechRecognizer.ERROR_NETWORK -> "Network connection error"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please try again."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognition service busy"
            SpeechRecognizer.ERROR_SERVER -> "Server error"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
            else -> "Speech recognition error ($errorCode)"
        }
    }

    companion object {
        private const val TAG = "SpeechRecognitionMgr"
    }
}
