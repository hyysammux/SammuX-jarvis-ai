package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JarvisScreen
import com.example.ui.components.JarvisArcReactor
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldDark
import com.example.ui.theme.JarvisTextSecondary
import com.example.voice.VoiceAssistantState
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    isFirstLaunchCompleted: Boolean,
    onNavigate: (JarvisScreen) -> Unit
) {
    var progress by remember { mutableFloatStateOf(0f) }
    var statusText by remember { mutableStateOf("INITIALIZING CORE SYSTEMS...") }

    LaunchedEffect(Unit) {
        delay(400)
        progress = 0.25f
        statusText = "VERIFYING CRYPTOGRAPHIC VAULT..."
        delay(450)
        progress = 0.55f
        statusText = "CALIBRATING ACOUSTIC RESONATORS..."
        delay(450)
        progress = 0.85f
        statusText = "SYNCHRONIZING NEURAL MATRIX..."
        delay(450)
        progress = 1.0f
        statusText = "JARVIS MARK VII ONLINE"
        delay(500)

        if (isFirstLaunchCompleted) {
            onNavigate(JarvisScreen.HOME)
        } else {
            onNavigate(JarvisScreen.WELCOME)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            JarvisArcReactor(
                state = VoiceAssistantState.IDLE,
                audioRmsDb = 4f,
                size = 200.dp
            )

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = "J. A. R. V. I. S.",
                color = JarvisGoldBright,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 4.sp
            )

            Text(
                text = "JUST A RATHER VERY INTELLIGENT SYSTEM",
                color = JarvisGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .size(width = 220.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = JarvisGold,
                trackColor = JarvisGoldDark.copy(alpha = 0.3f),
            )

            Spacer(modifier = Modifier.height(16.dp))

            AnimatedVisibility(
                visible = true,
                enter = fadeIn() + slideInVertically()
            ) {
                Text(
                    text = statusText,
                    color = JarvisTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
