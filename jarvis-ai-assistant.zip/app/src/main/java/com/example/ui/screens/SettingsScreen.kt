package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security.LanguagePreference
import com.example.ui.JarvisMainViewModel
import com.example.ui.JarvisScreen
import com.example.ui.JarvisUiState
import com.example.ui.components.JarvisHudCard
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldDark
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun SettingsScreen(
    uiState: JarvisUiState,
    viewModel: JarvisMainViewModel,
    onNavigateBack: () -> Unit
) {
    var strictness by remember { mutableFloatStateOf(uiState.verificationStrictness) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(horizontal = 16.dp)
    ) {
        // Top Header
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = JarvisGold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "SYSTEM CONFIGURATION",
                        color = JarvisGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Security & Neural Telemetry",
                        color = JarvisGoldBright,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // 1. Language & Vocal Cadence
        item {
            JarvisHudCard(
                modifier = Modifier.fillMaxWidth(),
                title = "Language & Cadence",
                badgeText = "Multi-Lingual"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Select default voice interaction language for speech synthesis and recognition:",
                        color = JarvisTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LanguageOptionChip(
                            label = "English (UK)",
                            isSelected = uiState.language == LanguagePreference.ENGLISH,
                            onClick = { viewModel.setLanguage(LanguagePreference.ENGLISH) }
                        )

                        LanguageOptionChip(
                            label = "हिन्दी (Hindi)",
                            isSelected = uiState.language == LanguagePreference.HINDI,
                            onClick = { viewModel.setLanguage(LanguagePreference.HINDI) }
                        )

                        LanguageOptionChip(
                            label = "Hinglish",
                            isSelected = uiState.language == LanguagePreference.HINGLISH,
                            onClick = { viewModel.setLanguage(LanguagePreference.HINGLISH) }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 2. Speaker Verification Biometrics
        item {
            val bio = uiState.enrolledBiometrics
            JarvisHudCard(
                modifier = Modifier.fillMaxWidth(),
                title = "Biometric Voice Vault",
                badgeText = if (bio != null) "CALIBRATED" else "PENDING"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (bio != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = JarvisGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Voiceprint baseline: ${bio.avgPitchHz.toInt()} Hz | ${bio.sampleCount} Samples Enrolled",
                                color = JarvisGoldBright,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Strictness & Sensitivity Slider
                    val sensitivityLabel = when {
                        strictness >= 0.75f -> "High / Maximum Security"
                        strictness >= 0.60f -> "Balanced (Recommended)"
                        else -> "Relaxed (Broad Recognition)"
                    }

                    Text(
                        text = "Speaker Verification Sensitivity: ${(strictness * 100).toInt()}% ($sensitivityLabel)",
                        color = JarvisGold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Slider(
                        value = strictness,
                        onValueChange = {
                            strictness = it
                            viewModel.setVerificationStrictness(it)
                        },
                        valueRange = 0.50f..0.85f,
                        colors = SliderDefaults.colors(
                            thumbColor = JarvisGoldBright,
                            activeTrackColor = JarvisGold,
                            inactiveTrackColor = JarvisGoldDark
                        )
                    )

                    // Sensitivity Presets
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PresetChip(
                            label = "Relaxed 50%",
                            isSelected = strictness in 0.49f..0.55f,
                            onClick = {
                                strictness = 0.50f
                                viewModel.setVerificationStrictness(0.50f)
                            }
                        )
                        PresetChip(
                            label = "Balanced 65%",
                            isSelected = strictness in 0.63f..0.67f,
                            onClick = {
                                strictness = 0.65f
                                viewModel.setVerificationStrictness(0.65f)
                            }
                        )
                        PresetChip(
                            label = "Strict 80%",
                            isSelected = strictness in 0.78f..0.85f,
                            onClick = {
                                strictness = 0.80f
                                viewModel.setVerificationStrictness(0.80f)
                            }
                        )
                    }

                    // Retrain Voice Button
                    Button(
                        onClick = { viewModel.resetVoiceProfile() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("retrain_voice_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = JarvisGold,
                            contentColor = JarvisBlack
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "RETRAIN VOICE (RE-CALIBRATE)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Verification Simulation & Testing Section
                    Text(
                        text = "SPEAKER VERIFICATION TESTING",
                        color = JarvisGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.testEnrolledVoiceCommand("Hey Jarvis, what is the battery status?")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisGreen),
                            border = androidx.compose.foundation.BorderStroke(1.dp, JarvisGreen.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = "TEST OWNER VOICE\n(\"Yes Sir, I'm listening\")",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.testUnauthorizedSpeakerAttempt("Hey Jarvis, turn on flashlight")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisRed),
                            border = androidx.compose.foundation.BorderStroke(1.dp, JarvisRed.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = "TEST UNKNOWN VOICE\n(\"Voice not recognized\")",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 3. Background Wake Word & Battery Optimization
        item {
            JarvisHudCard(
                modifier = Modifier.fillMaxWidth(),
                title = "Continuous Voice & Battery Telemetry",
                badgeText = if (uiState.isBackgroundServiceActive) "RUNNING" else "STANDBY"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Foreground Voice Service",
                                color = JarvisGoldBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Listens for 'Hey Jarvis' in the background with persistent status notification.",
                                color = JarvisTextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Switch(
                            checked = uiState.isBackgroundServiceActive,
                            onCheckedChange = { viewModel.toggleBackgroundService(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = JarvisGoldBright,
                                checkedTrackColor = JarvisGoldDark
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { viewModel.requestIgnoreBatteryOptimizations() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, JarvisCyan.copy(alpha = 0.7f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = JarvisCyan
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "OPTIMIZE BATTERY RESTRICTIONS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 4. Safety & User Control (Confirmation Mode)
        item {
            JarvisHudCard(
                modifier = Modifier.fillMaxWidth(),
                title = "Safety & User Confirmation",
                badgeText = if (uiState.isConfirmationRequired) "STRICT CONTROL" else "AUTO-PILOT"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Confirm Before Dispatching",
                                color = JarvisGoldBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Voice drafts are read aloud and require explicit confirmation ('Yes, send it') before dispatch. No action is ever taken without your clear command.",
                                color = JarvisTextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Switch(
                            checked = uiState.isConfirmationRequired,
                            onCheckedChange = { viewModel.setConfirmationRequired(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = JarvisGoldBright,
                                checkedTrackColor = JarvisGoldDark
                            )
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 5. System Automation & Accessibility Settings
        item {
            JarvisHudCard(
                modifier = Modifier.fillMaxWidth(),
                title = "Automation & Accessibility Bridge",
                badgeText = "SYSTEM PERMISSIONS"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Enable system listeners to allow JARVIS to read notifications aloud, support RemoteInput replies, and assist with UI navigation:",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.openNotificationSettings() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisGold),
                            border = androidx.compose.foundation.BorderStroke(1.dp, JarvisGold)
                        ) {
                            Text(
                                text = "NOTIFICATIONS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.openAccessibilitySettings() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisGold),
                            border = androidx.compose.foundation.BorderStroke(1.dp, JarvisGold)
                        ) {
                            Text(
                                text = "ACCESSIBILITY",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 6. Android Compliance & Honesty Matrix
        item {
            JarvisHudCard(
                modifier = Modifier.fillMaxWidth(),
                title = "Android Compliance & Boundaries",
                badgeText = "SANDBOX POLICY"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "JARVIS strictly obeys Android security models. Never guessing or hallucinating impossible actions:",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    SecurityStatusRow(
                        label = "✔ Deep Link App Launch:",
                        value = "Permitted & Active"
                    )
                    SecurityStatusRow(
                        label = "✔ Notification RemoteInput:",
                        value = "User-Confirmed Only"
                    )
                    SecurityStatusRow(
                        label = "✔ Speaker Verification:",
                        value = "100% On-Device DSP"
                    )
                    SecurityStatusRow(
                        label = "✖ Secret Background Eavesdropping:",
                        value = "Blocked by Android OS"
                    )
                    SecurityStatusRow(
                        label = "✖ Silent Snapchat Scraping:",
                        value = "Blocked by E2EE Sandboxing"
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 7. Security & Cryptography Card
        item {
            JarvisHudCard(
                modifier = Modifier.fillMaxWidth(),
                title = "Cryptographic Security Status",
                badgeText = "AES-256 GCM"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    SecurityStatusRow(
                        label = "Key Encryption:",
                        value = "MasterKey KeyGenParameterSpec"
                    )
                    SecurityStatusRow(
                        label = "Storage Scheme:",
                        value = "EncryptedSharedPreferences (AES256_SIV)"
                    )
                    SecurityStatusRow(
                        label = "Biometric Model:",
                        value = "On-Device Feature Autocorrelation"
                    )
                    SecurityStatusRow(
                        label = "Data Isolation:",
                        value = "100% On-Device Sandboxed"
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LanguageOptionChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontFamily = FontFamily.Monospace
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = JarvisGold,
            selectedLabelColor = JarvisBlack,
            containerColor = JarvisBlack,
            labelColor = JarvisTextSecondary
        ),
        border = FilterChipDefaults.filterChipBorder(
            borderColor = if (isSelected) JarvisGoldBright else JarvisGoldBorder,
            selectedBorderColor = JarvisGoldBright,
            enabled = true,
            selected = isSelected
        )
    )
}

@Composable
private fun SecurityStatusRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = JarvisTextSecondary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = JarvisGoldBright,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun PresetChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontFamily = FontFamily.Monospace
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = JarvisGold,
            selectedLabelColor = JarvisBlack,
            containerColor = JarvisBlack,
            labelColor = JarvisTextSecondary
        ),
        border = FilterChipDefaults.filterChipBorder(
            borderColor = if (isSelected) JarvisGoldBright else JarvisGoldBorder,
            selectedBorderColor = JarvisGoldBright,
            enabled = true,
            selected = isSelected
        )
    )
}
