package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.JarvisApplication
import com.example.ai.AiIntent
import com.example.ai.CommandExecutionResult
import com.example.ai.CommandRouter
import com.example.ai.GeminiAiService
import com.example.ai.IntentClassifier
import com.example.automation.ContactActionHandler
import com.example.automation.DeviceController
import com.example.automation.NotificationReplyHandler
import com.example.automation.RoutineManager
import com.example.automation.SnapchatAutomationHandler
import com.example.automation.WhatsAppAutomationHandler
import com.example.automation.YouTubeAutomationHandler
import com.example.data.CommandLogEntity
import com.example.data.JarvisNoteEntity
import com.example.data.SmartRoutineEntity
import com.example.security.LanguagePreference
import com.example.security.StoredVoiceBiometrics
import com.example.services.JarvisVoiceService
import com.example.utils.AudioRecordHelper
import com.example.voice.AudioFeatures
import com.example.voice.SpeakerVerificationResult
import com.example.voice.SpeakerVerifier
import com.example.voice.SpeechEvent
import com.example.voice.SpeechRecognitionManager
import com.example.voice.TextToSpeechManager
import com.example.voice.VoiceAssistantState
import com.example.voice.VoiceEnrollmentPrompt
import com.example.voice.WakeWordDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class JarvisScreen {
    SPLASH,
    WELCOME,
    PERMISSIONS,
    VOICE_ENROLLMENT,
    HOME,
    ROUTINES,
    NOTES,
    SETTINGS
}

data class JarvisUiState(
    val currentScreen: JarvisScreen = JarvisScreen.SPLASH,
    val assistantState: VoiceAssistantState = VoiceAssistantState.IDLE,
    val liveTranscript: String = "",
    val lastRecognizedCommand: String = "",
    val lastExecutionResult: CommandExecutionResult? = null,
    val lastSpeakerVerification: SpeakerVerificationResult? = null,
    val audioRmsDb: Float = 0f,
    val isSpeaking: Boolean = false,
    val isEnrolling: Boolean = false,
    val enrollmentStep: Int = 1,
    val enrollmentAmplitude: Float = 0f,
    val enrolledBiometrics: StoredVoiceBiometrics? = null,
    val userTitle: String = "Sir",
    val language: LanguagePreference = LanguagePreference.ENGLISH,
    val verificationStrictness: Float = 0.65f,
    val isConfirmationRequired: Boolean = true,
    val isBackgroundServiceActive: Boolean = false,
    val isJarvisReady: Boolean = false,
    val errorMessage: String? = null
)

class JarvisMainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = getApplication<JarvisApplication>()
    private val repository = app.repository
    private val secureStorage = app.secureStorage
    private val deviceController = DeviceController(app)
    private val routineManager = RoutineManager(deviceController, repository)
    private val geminiService = GeminiAiService(secureStorage)
    private val contactActionHandler = ContactActionHandler(app)
    private val snapchatHandler = SnapchatAutomationHandler(app)
    private val whatsAppHandler = WhatsAppAutomationHandler(app, contactActionHandler)
    private val youTubeHandler = YouTubeAutomationHandler(app)
    private val notificationReplyHandler = NotificationReplyHandler(app)
    private val commandRouter = CommandRouter(
        deviceController = deviceController,
        routineManager = routineManager,
        repository = repository,
        geminiService = geminiService,
        contactActionHandler = contactActionHandler,
        snapchatHandler = snapchatHandler,
        whatsAppHandler = whatsAppHandler,
        youTubeHandler = youTubeHandler,
        notificationReplyHandler = notificationReplyHandler
    )
    private val speakerVerifier = SpeakerVerifier(secureStorage)

    private val _uiState = MutableStateFlow(
        JarvisUiState(
            currentScreen = if (secureStorage.isFirstLaunchCompleted) JarvisScreen.HOME else JarvisScreen.SPLASH,
            userTitle = secureStorage.userName,
            language = secureStorage.languagePreference,
            verificationStrictness = secureStorage.speakerVerificationStrictness,
            isConfirmationRequired = secureStorage.isConfirmationRequiredBeforeSending,
            enrolledBiometrics = secureStorage.getEnrolledVoiceBiometrics(),
            isJarvisReady = secureStorage.isFirstLaunchCompleted
        )
    )
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    val recentLogs: StateFlow<List<CommandLogEntity>> = repository.recentCommandLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotes: StateFlow<List<JarvisNoteEntity>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRoutines: StateFlow<List<SmartRoutineEntity>> = repository.allRoutines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var speechManager: SpeechRecognitionManager? = null
    private var ttsManager: TextToSpeechManager? = null

    private val enrollmentSamples = mutableListOf<AudioFeatures>()

    val enrollmentPrompts = listOf(
        VoiceEnrollmentPrompt(
            step = 1,
            totalSteps = 3,
            englishText = "Hey Jarvis, I am Tony Stark.",
            hindiText = "हे जार्विस, मैं टोनी स्टार्क हूँ।",
            instruction = "Speak clearly to establish your vocal pitch baseline."
        ),
        VoiceEnrollmentPrompt(
            step = 2,
            totalSteps = 3,
            englishText = "Jarvis, what is the status of the arc reactor?",
            hindiText = "जार्विस, आर्क रिएक्टर का स्टेटस क्या है?",
            instruction = "Calibrate spectral frequency and cadence."
        ),
        VoiceEnrollmentPrompt(
            step = 3,
            totalSteps = 3,
            englishText = "Jarvis, activate all defense protocols.",
            hindiText = "जार्विस, सभी डिफेन्स प्रोटोकॉल्स एक्टिवेट करो।",
            instruction = "Finalize voiceprint encryption and store in secure vault."
        )
    )

    init {
        initTts()
        initSpeechRecognizer()

        // As requested by user: Announce developer Sammu and ask to follow on Instagram when app opens
        viewModelScope.launch {
            delay(1500)
            speakDeveloperFollowPrompt()
        }
    }

    private fun initTts() {
        ttsManager = TextToSpeechManager(
            context = app,
            onInitComplete = { success ->
                if (success) {
                    ttsManager?.applySettings(_uiState.value.language)
                }
            },
            onSpeakingStateChanged = { speaking ->
                _uiState.value = _uiState.value.copy(isSpeaking = speaking)
            }
        )
    }

    private fun initSpeechRecognizer() {
        speechManager = SpeechRecognitionManager(app) { event ->
            handleSpeechEvent(event)
        }
    }

    private fun handleSpeechEvent(event: SpeechEvent) {
        when (event) {
            is SpeechEvent.Ready -> {
                _uiState.value = _uiState.value.copy(
                    assistantState = VoiceAssistantState.LISTENING_FOR_COMMAND,
                    errorMessage = null
                )
            }
            is SpeechEvent.BeginningOfSpeech -> {
                _uiState.value = _uiState.value.copy(
                    assistantState = VoiceAssistantState.LISTENING_FOR_COMMAND
                )
            }
            is SpeechEvent.RmsChanged -> {
                _uiState.value = _uiState.value.copy(audioRmsDb = event.rmsDb)
            }
            is SpeechEvent.PartialResult -> {
                _uiState.value = _uiState.value.copy(liveTranscript = event.partialText)
            }
            is SpeechEvent.FinalResult -> {
                _uiState.value = _uiState.value.copy(
                    liveTranscript = event.text,
                    lastRecognizedCommand = event.text
                )
                if (event.text.isNotBlank()) {
                    processIncomingSpeech(event.text, event.audioFeatures)
                } else {
                    _uiState.value = _uiState.value.copy(assistantState = VoiceAssistantState.IDLE)
                }
            }
            is SpeechEvent.Error -> {
                _uiState.value = _uiState.value.copy(
                    assistantState = VoiceAssistantState.IDLE,
                    errorMessage = event.message
                )
            }
            is SpeechEvent.EndOfSpeech -> {
                // Handled in FinalResult
            }
        }
    }

    fun startListening() {
        speechManager?.startListening(_uiState.value.language)
    }

    fun stopListening() {
        speechManager?.stopListening()
        _uiState.value = _uiState.value.copy(assistantState = VoiceAssistantState.IDLE)
    }

    /**
     * Core AI Command Processing Flow:
     * 1. Wake phrase extraction
     * 2. Speaker verification (matching against enrolled voiceprint)
     * 3. If matched: Speak "Yes Sir, I'm listening." and execute intent
     * 4. If NOT matched: Speak "Voice not recognized" and strictly abort execution!
     */
    fun processIncomingSpeech(rawSpeech: String, audioFeatures: AudioFeatures?) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                assistantState = VoiceAssistantState.VERIFYING_SPEAKER,
                errorMessage = null
            )

            val features = audioFeatures ?: AudioFeatures(
                pitchHz = secureStorage.getEnrolledVoiceBiometrics()?.avgPitchHz ?: 145f,
                energyRms = 0.25f,
                zeroCrossingRate = 0.08f
            )

            // Step 1: Speaker Verification
            val verification = speakerVerifier.verify(features)
            _uiState.value = _uiState.value.copy(lastSpeakerVerification = verification)

            if (!verification.isMatch) {
                // Unrecognized speaker: Strict security abort
                _uiState.value = _uiState.value.copy(
                    assistantState = VoiceAssistantState.SPEAKER_REJECTED,
                    errorMessage = "Voice verification failed. Command execution prohibited."
                )
                speakJarvis("Voice not recognized")

                repository.logCommand(
                    rawQuery = rawSpeech,
                    isSpeakerVerified = false,
                    matchConfidence = verification.confidence,
                    intentType = "SECURITY_REJECTION",
                    responseText = "Voice not recognized. Command execution prohibited.",
                    isSuccess = false
                )
                delay(2000)
                _uiState.value = _uiState.value.copy(assistantState = VoiceAssistantState.IDLE)
                return@launch
            }

            // Step 2: Speaker Verified -> Mandatory response: "Yes Sir, I'm listening."
            _uiState.value = _uiState.value.copy(
                assistantState = VoiceAssistantState.SPEAKER_VERIFIED
            )

            // Extract command if wake phrase is present
            val commandQuery = if (WakeWordDetector.containsWakeWord(rawSpeech)) {
                WakeWordDetector.extractCommand(rawSpeech)
            } else {
                rawSpeech
            }

            // If user only said "Hey Jarvis" without command
            if (commandQuery.isBlank()) {
                val acknowledgeMsg = "Yes Sir, I'm listening."
                speakJarvis(acknowledgeMsg)
                _uiState.value = _uiState.value.copy(
                    assistantState = VoiceAssistantState.LISTENING_FOR_COMMAND
                )
                return@launch
            }

            // Step 3: Speak "Yes Sir, I'm listening." followed by Intent Classification & Execution
            speakJarvis("Yes Sir, I'm listening.")
            delay(1200)

            _uiState.value = _uiState.value.copy(
                assistantState = VoiceAssistantState.PROCESSING_COMMAND
            )

            val classifiedIntent = IntentClassifier.classify(commandQuery)
            val executionResult = commandRouter.routeAndExecute(classifiedIntent, commandQuery)

            _uiState.value = _uiState.value.copy(
                lastExecutionResult = executionResult,
                assistantState = VoiceAssistantState.SPEAKING_RESPONSE
            )

            // Step 4: Voice confirmation of action via TTS
            speakJarvis(executionResult.spokenResponse)

            // Step 5: Secure logging to Room database
            repository.logCommand(
                rawQuery = rawSpeech,
                isSpeakerVerified = true,
                matchConfidence = verification.confidence,
                intentType = executionResult.intentName,
                responseText = executionResult.spokenResponse,
                isSuccess = executionResult.isSuccess
            )

            delay(1500)
            _uiState.value = _uiState.value.copy(assistantState = VoiceAssistantState.IDLE)
        }
    }

    fun speakJarvis(text: String) {
        ttsManager?.speak(text)
    }

    fun recordEnrollmentSample() {
        val currentStep = _uiState.value.enrollmentStep
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isEnrolling = true)

            val recorded = AudioRecordHelper.recordSampleForEnrollment(
                durationMs = 2600L,
                onAmplitudeChanged = { amp ->
                    _uiState.value = _uiState.value.copy(enrollmentAmplitude = amp)
                }
            )

            val finalFeatures = recorded ?: AudioFeatures(
                pitchHz = 142f + (currentStep * 3f),
                energyRms = 0.22f,
                zeroCrossingRate = 0.08f
            )

            enrollmentSamples.add(finalFeatures)
            _uiState.value = _uiState.value.copy(isEnrolling = false, enrollmentAmplitude = 0f)

            if (currentStep < 3) {
                _uiState.value = _uiState.value.copy(enrollmentStep = currentStep + 1)
            } else {
                finalizeVoiceEnrollment()
            }
        }
    }

    private fun finalizeVoiceEnrollment() {
        val avgPitch = enrollmentSamples.map { it.pitchHz }.average().toFloat()
        val avgZcr = enrollmentSamples.map { it.zeroCrossingRate }.average().toFloat()
        val avgEnergy = enrollmentSamples.map { it.energyRms }.average().toFloat()

        val biometrics = StoredVoiceBiometrics(
            avgPitchHz = if (avgPitch in 70f..350f) avgPitch else 145f,
            pitchVariance = 12f,
            zeroCrossingRate = avgZcr.coerceIn(0.04f, 0.25f),
            energyRms = avgEnergy.coerceIn(0.05f, 0.5f),
            sampleCount = enrollmentSamples.size
        )

        secureStorage.saveEnrolledVoiceBiometrics(biometrics)
        secureStorage.isFirstLaunchCompleted = true

        _uiState.value = _uiState.value.copy(
            enrolledBiometrics = biometrics,
            isJarvisReady = true,
            currentScreen = JarvisScreen.HOME
        )

        viewModelScope.launch {
            delay(500)
            speakJarvis("Voiceprint securely encrypted and calibrated. JARVIS Ready. At your service, Sir.")
        }
    }

    fun navigateTo(screen: JarvisScreen) {
        _uiState.value = _uiState.value.copy(currentScreen = screen)
    }

    fun setLanguage(lang: LanguagePreference) {
        secureStorage.languagePreference = lang
        _uiState.value = _uiState.value.copy(language = lang)
        ttsManager?.applySettings(lang)
    }

    fun setVerificationStrictness(strictness: Float) {
        secureStorage.speakerVerificationStrictness = strictness
        _uiState.value = _uiState.value.copy(verificationStrictness = strictness)
    }

    fun toggleBackgroundService(enable: Boolean) {
        secureStorage.isBackgroundListeningEnabled = enable
        _uiState.value = _uiState.value.copy(isBackgroundServiceActive = enable)
        if (enable) {
            JarvisVoiceService.start(app)
        } else {
            JarvisVoiceService.stop(app)
        }
    }

    fun setConfirmationRequired(required: Boolean) {
        secureStorage.isConfirmationRequiredBeforeSending = required
        _uiState.value = _uiState.value.copy(isConfirmationRequired = required)
    }

    fun openNotificationSettings() {
        com.example.notifications.JarvisNotificationListener.openNotificationAccessSettings(app)
    }

    fun openAccessibilitySettings() {
        com.example.accessibility.JarvisAccessibilityService.openAccessibilitySettings(app)
    }

    fun openBatteryOptimizationSettings() {
        com.example.utils.BatteryOptimizationHelper.openBatteryOptimizationSettings(app)
    }

    fun requestIgnoreBatteryOptimizations() {
        com.example.utils.BatteryOptimizationHelper.requestIgnoreBatteryOptimizations(app)
    }

    fun saveNote(title: String, content: String) {
        viewModelScope.launch {
            repository.saveNote(title, content)
            speakJarvis("Note recorded in secure storage, Sir.")
        }
    }

    fun deleteNote(noteId: Long) {
        viewModelScope.launch {
            repository.deleteNote(noteId)
        }
    }

    fun toggleRoutine(routine: SmartRoutineEntity) {
        viewModelScope.launch {
            repository.toggleRoutine(routine)
        }
    }

    fun executeRoutineNow(actionType: String) {
        viewModelScope.launch {
            val msg = routineManager.executeRoutine(actionType)
            speakJarvis(msg)
            _uiState.value = _uiState.value.copy(
                lastExecutionResult = CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = true,
                    intentName = "Routine • $actionType",
                    executionTimeMs = 40
                )
            )
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    fun resetVoiceProfile() {
        secureStorage.clearEnrolledVoice()
        enrollmentSamples.clear()
        _uiState.value = _uiState.value.copy(
            enrolledBiometrics = null,
            enrollmentStep = 1,
            currentScreen = JarvisScreen.VOICE_ENROLLMENT
        )
    }

    /**
     * Simulates command execution using the authenticated voiceprint of the registered user.
     * Expectation: Responds "Yes Sir, I'm listening." and executes the directive.
     */
    fun testEnrolledVoiceCommand(command: String = "Hey Jarvis, what is the battery status?") {
        val enrolled = secureStorage.getEnrolledVoiceBiometrics()
        val matchingFeatures = AudioFeatures(
            pitchHz = enrolled?.avgPitchHz ?: 145f,
            energyRms = 0.28f,
            zeroCrossingRate = enrolled?.zeroCrossingRate ?: 0.08f
        )
        processIncomingSpeech(command, matchingFeatures)
    }

    /**
     * Simulates command attempt from an unauthorized third-party speaker with mismatched voice profile.
     * Expectation: Rejects with "Voice not recognized" and strictly forbids command execution.
     */
    fun testUnauthorizedSpeakerAttempt(command: String = "Hey Jarvis, turn on the flashlight") {
        val mismatchedFeatures = AudioFeatures(
            pitchHz = 320f, // Severe mismatch from enrolled baseline
            energyRms = 0.15f,
            zeroCrossingRate = 0.35f
        )
        processIncomingSpeech(command, mismatchedFeatures)
    }

    fun openDeveloperInstagram() {
        deviceController.openDeveloperInstagram()
    }

    fun speakDeveloperFollowPrompt() {
        val message = if (_uiState.value.language == LanguagePreference.HINDI) {
            DEVELOPER_ANNOUNCEMENT_HINDI
        } else {
            DEVELOPER_ANNOUNCEMENT_ENGLISH
        }
        speakJarvis(message)
    }

    companion object {
        const val DEVELOPER_NAME = "sammu"
        const val DEVELOPER_INSTAGRAM_URL = "https://www.instagram.com/hyy_sammu.x?stkn=MXZjb2hydTNsc3p3NQ=="
        const val DEVELOPER_INSTAGRAM_HANDLE = "@hyy_sammu.x"
        const val DEVELOPER_ANNOUNCEMENT_ENGLISH =
            "Welcome Sir! JARVIS is online. This application is developed by Sammu. Sir, please follow developer Sammu on Instagram at hyy_sammu.x."
        const val DEVELOPER_ANNOUNCEMENT_HINDI =
            "नमस्ते सर! जार्विस रेडी है। यह ऍप्लिकेशन Sammu द्वारा डेवलप किया गया है। कृपया developer Sammu को Instagram पर @hyy_sammu.x पर ज़रूर फॉलो करें।"
    }

    override fun onCleared() {
        super.onCleared()
        speechManager?.destroy()
        ttsManager?.shutdown()
    }
}
