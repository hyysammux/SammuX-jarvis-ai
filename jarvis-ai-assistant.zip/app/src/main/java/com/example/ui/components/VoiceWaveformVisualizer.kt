package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldDark
import kotlin.math.sin

@Composable
fun VoiceWaveformVisualizer(
    isActive: Boolean,
    amplitude: Float,
    modifier: Modifier = Modifier,
    barCount: Int = 24,
    height: Dp = 48.dp
) {
    val transition = rememberInfiniteTransition(label = "wave_anim")
    val waveOffset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f, // 2*PI
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_offset"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(height)) {
            val totalWidth = size.width
            val totalHeight = size.height
            val spacing = totalWidth / (barCount * 1.5f)
            val barWidth = spacing * 0.7f
            val startX = (totalWidth - (barCount * spacing)) / 2f
            val centerY = totalHeight / 2f

            for (i in 0 until barCount) {
                val normalizedIndex = i.toFloat() / barCount
                // Sine wave variation
                val waveFactor = (sin(waveOffset + (normalizedIndex * 4f)) + 1f) / 2f

                val calculatedHeight = if (isActive) {
                    val base = 8.dp.toPx()
                    val dynamic = (amplitude * totalHeight * 0.75f) + (waveFactor * totalHeight * 0.35f)
                    (base + dynamic).coerceIn(6.dp.toPx(), totalHeight)
                } else {
                    4.dp.toPx()
                }

                val x = startX + (i * spacing)
                val topY = centerY - (calculatedHeight / 2f)

                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = if (isActive) {
                            listOf(JarvisGoldBright, JarvisGold, JarvisCyan)
                        } else {
                            listOf(JarvisGoldDark, JarvisGoldDark.copy(alpha = 0.4f))
                        }
                    ),
                    topLeft = Offset(x, topY),
                    size = Size(barWidth, calculatedHeight),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )
            }
        }
    }
}
