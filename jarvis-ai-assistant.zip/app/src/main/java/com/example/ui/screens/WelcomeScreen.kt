package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JarvisScreen
import com.example.ui.components.JarvisArcReactor
import com.example.ui.components.JarvisHudCard
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldContainer
import com.example.ui.theme.JarvisSurfaceCard
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.voice.VoiceAssistantState

@Composable
fun WelcomeScreen(
    onNavigate: (JarvisScreen) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            JarvisArcReactor(
                state = VoiceAssistantState.IDLE,
                audioRmsDb = 2f,
                size = 140.dp
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "WELCOME, SIR",
                color = JarvisGoldBright,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )

            Text(
                text = "Autonomous Voice AI & Device Automation",
                color = JarvisTextSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Capabilities list
            WelcomeFeatureItem(
                icon = Icons.Default.Fingerprint,
                title = "Biometric Speaker Verification",
                description = "Strict voiceprint authentication. Unrecognized voices are locked out instantly."
            )

            Spacer(modifier = Modifier.height(12.dp))

            WelcomeFeatureItem(
                icon = Icons.Default.Mic,
                title = "Wake Phrase & Dual-Language",
                description = "Trigger via 'Hey Jarvis'. Fully fluent in English, Hindi (हिन्दी), and Hinglish."
            )

            Spacer(modifier = Modifier.height(12.dp))

            WelcomeFeatureItem(
                icon = Icons.Default.Psychology,
                title = "Intelligent Intent Routing",
                description = "Direct hardware controls, routines, memory notes, and Gemini AI reasoning."
            )

            Spacer(modifier = Modifier.height(12.dp))

            WelcomeFeatureItem(
                icon = Icons.Default.Security,
                title = "Encrypted On-Device Vault",
                description = "AndroidX AES-256 GCM cryptographic protection. Your biometric data never leaves your device."
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { onNavigate(JarvisScreen.PERMISSIONS) },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("get_started_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = JarvisGold,
                contentColor = JarvisBlack
            )
        ) {
            Text(
                text = "COMMENCE PROTOCOL SETUP",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun WelcomeFeatureItem(
    icon: ImageVector,
    title: String,
    description: String
) {
    JarvisHudCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(JarvisGoldContainer, CircleShape)
                    .border(1.dp, JarvisGoldBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = JarvisGold,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = JarvisGoldBright,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = description,
                    color = JarvisTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}
