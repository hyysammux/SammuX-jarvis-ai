package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val JarvisColorScheme = darkColorScheme(
    primary = JarvisGold,
    onPrimary = JarvisBlack,
    primaryContainer = JarvisGoldContainer,
    onPrimaryContainer = JarvisGoldBright,
    secondary = JarvisGoldBright,
    onSecondary = JarvisBlack,
    secondaryContainer = JarvisSurfaceCard,
    onSecondaryContainer = JarvisGold,
    tertiary = JarvisCyan,
    onTertiary = JarvisBlack,
    background = JarvisBlack,
    onBackground = JarvisTextPrimary,
    surface = JarvisSurface,
    onSurface = JarvisTextPrimary,
    surfaceVariant = JarvisSurfaceCard,
    onSurfaceVariant = JarvisTextSecondary,
    outline = JarvisGoldBorder,
    outlineVariant = JarvisGoldDark,
    error = JarvisRed,
    onError = JarvisBlack
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // JARVIS is strictly designed as a luxurious, immersive Black & Gold HUD interface
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
