package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CommandLogEntity
import com.example.ui.JarvisMainViewModel
import com.example.ui.JarvisScreen
import com.example.ui.JarvisUiState
import com.example.ui.components.JarvisArcReactor
import com.example.ui.components.JarvisHudCard
import com.example.ui.components.VoiceWaveformVisualizer
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldContainer
import com.example.ui.theme.JarvisGoldDark
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisSurfaceCard
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.voice.VoiceAssistantState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    uiState: JarvisUiState,
    recentLogs: List<CommandLogEntity>,
    viewModel: JarvisMainViewModel,
    onNavigate: (JarvisScreen) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Top HUD Bar
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "J.A.R.V.I.S.",
                        color = JarvisGoldBright,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "MARK VII • NEURAL CORE ACTIVE",
                        color = JarvisGold,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Status Badge
                    Box(
                        modifier = Modifier
                            .background(JarvisGoldContainer, RoundedCornerShape(20.dp))
                            .border(1.dp, JarvisGoldBorder, RoundedCornerShape(20.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(JarvisGreen, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "JARVIS READY",
                                color = JarvisGoldBright,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { onNavigate(JarvisScreen.SETTINGS) },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = JarvisGold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // 2. Arc Reactor Hero & Voice Trigger
        item {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .padding(vertical = 8.dp)
                    .clickable {
                        if (uiState.assistantState == VoiceAssistantState.IDLE) {
                            viewModel.startListening()
                        } else {
                            viewModel.stopListening()
                        }
                    }
                    .testTag("arc_reactor_voice_toggle")
            ) {
                JarvisArcReactor(
                    state = uiState.assistantState,
                    audioRmsDb = uiState.audioRmsDb,
                    size = 210.dp
                )
            }

            // State readout text
            val statusLabel = when (uiState.assistantState) {
                VoiceAssistantState.IDLE -> "STANDBY • TAP OR SAY 'HEY JARVIS'"
                VoiceAssistantState.LISTENING_FOR_COMMAND -> "LISTENING • SPEAK COMMAND..."
                VoiceAssistantState.VERIFYING_SPEAKER -> "VERIFYING BIOMETRIC VOICEPRINT..."
                VoiceAssistantState.SPEAKER_VERIFIED -> "SPEAKER VERIFIED • YES SIR, I'M LISTENING"
                VoiceAssistantState.SPEAKER_REJECTED -> "VOICE NOT RECOGNIZED • COMMAND BLOCKED"
                VoiceAssistantState.PROCESSING_COMMAND -> "EXECUTING PROTOCOL..."
                VoiceAssistantState.SPEAKING_RESPONSE -> "JARVIS AUDIO FEEDBACK ACTIVE"
                else -> "JARVIS STANDBY"
            }

            val statusColor = when (uiState.assistantState) {
                VoiceAssistantState.SPEAKER_VERIFIED -> JarvisGreen
                VoiceAssistantState.SPEAKER_REJECTED -> JarvisRed
                VoiceAssistantState.LISTENING_FOR_COMMAND -> JarvisCyan
                VoiceAssistantState.SPEAKING_RESPONSE -> JarvisGoldBright
                else -> JarvisGold
            }

            Text(
                text = statusLabel,
                color = statusColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 10.dp)
            )

            // Waveform visualizer
            VoiceWaveformVisualizer(
                isActive = uiState.assistantState != VoiceAssistantState.IDLE,
                amplitude = if (uiState.assistantState != VoiceAssistantState.IDLE) 0.35f + (uiState.audioRmsDb / 20f) else 0f,
                height = 36.dp,
                modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
            )
        }

        // Developer Attribution & Instagram Follow Card
        item {
            JarvisHudCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .testTag("developer_attribution_card"),
                title = "DEVELOPER RECOGNITION",
                badgeText = "CREATOR: SAMMU"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Developed by Sammu",
                                color = JarvisGoldBright,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Instagram: @hyy_sammu.x",
                                color = JarvisCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.speakDeveloperFollowPrompt() },
                            modifier = Modifier
                                .size(36.dp)
                                .background(JarvisGoldContainer, CircleShape)
                                .border(1.dp, JarvisGoldBorder, CircleShape)
                                .testTag("hear_developer_announcement_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Hear follow invitation",
                                tint = JarvisGoldBright,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = "Follow developer Sammu on Instagram for official updates and upcoming JARVIS Mark VII capabilities.",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(top = 6.dp, bottom = 10.dp)
                    )

                    Button(
                        onClick = { viewModel.openDeveloperInstagram() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("follow_sammu_instagram_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = JarvisGold,
                            contentColor = JarvisBlack
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = JarvisBlack
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "FOLLOW SAMMU ON INSTAGRAM",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // 3. Live Speech / Transcript Card
        item {
            AnimatedVisibility(
                visible = uiState.liveTranscript.isNotBlank(),
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                JarvisHudCard(
                    modifier = Modifier.padding(bottom = 12.dp),
                    title = "Speech Transducer",
                    badgeText = "Live Input"
                ) {
                    Text(
                        text = "\"${uiState.liveTranscript}\"",
                        color = JarvisGoldBright,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.SansSerif
                    )
                }
            }
        }

        // 4. Last Command Execution Result HUD Card
        item {
            val result = uiState.lastExecutionResult
            if (result != null) {
                JarvisHudCard(
                    modifier = Modifier.padding(bottom = 12.dp),
                    title = result.intentName,
                    badgeText = "${result.executionTimeMs}ms • CONFIRMED",
                    borderColor = if (result.isSuccess) JarvisGold else JarvisRed
                ) {
                    Column {
                        Text(
                            text = result.visualDisplay,
                            color = JarvisTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "PROTOCOL VERIFIED",
                                color = if (result.isSuccess) JarvisGreen else JarvisRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )

                            Text(
                                text = "VOICE CONFIRMED",
                                color = JarvisGold,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // 5. Quick Command Shortcuts (Horizontal Scroll)
        item {
            Text(
                text = "SYSTEM COMMAND DIRECTIVES",
                color = JarvisGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    CommandChip(
                        icon = Icons.Default.CheckCircle,
                        label = "Test: Owner Voice",
                        onClick = { viewModel.testEnrolledVoiceCommand("Hey Jarvis, what is the battery status?") }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.Warning,
                        label = "Test: Unknown Voice",
                        onClick = { viewModel.testUnauthorizedSpeakerAttempt("Hey Jarvis, turn on flashlight") }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.PlayArrow,
                        label = "Open YouTube",
                        onClick = { viewModel.processIncomingSpeech("Open YouTube", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.Search,
                        label = "Search Tech Master Tool",
                        onClick = { viewModel.processIncomingSpeech("Search Tech Master Tool", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.CameraAlt,
                        label = "Open Instagram",
                        onClick = { viewModel.processIncomingSpeech("Open Instagram", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.Phone,
                        label = "Call Butki",
                        onClick = { viewModel.processIncomingSpeech("Call Butki", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.Notifications,
                        label = "Read Notifications",
                        onClick = { viewModel.processIncomingSpeech("Read notifications", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.FlashlightOn,
                        label = "Flashlight",
                        onClick = { viewModel.processIncomingSpeech("turn on flashlight", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.BatteryChargingFull,
                        label = "Battery Check",
                        onClick = { viewModel.processIncomingSpeech("battery status", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.VolumeUp,
                        label = "Volume Up",
                        onClick = { viewModel.processIncomingSpeech("volume up", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.Security,
                        label = "Security Scan",
                        onClick = { viewModel.executeRoutineNow("SECURITY_CHECK") }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.Psychology,
                        label = "Who are you?",
                        onClick = { viewModel.processIncomingSpeech("who are you jarvis", null) }
                    )
                }
                item {
                    CommandChip(
                        icon = Icons.Default.Mic,
                        label = "टॉर्च चालू करो",
                        onClick = { viewModel.processIncomingSpeech("torch chalu karo", null) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // 6. Security Log & Telemetry Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "COMMAND TELEMETRY & SECURITY LOGS",
                    color = JarvisGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                if (recentLogs.isNotEmpty()) {
                    Text(
                        text = "CLEAR",
                        color = JarvisGoldDark,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.clickable { viewModel.clearLogs() }
                    )
                }
            }
        }

        // 7. Recent Command Logs List
        if (recentLogs.isEmpty()) {
            item {
                JarvisHudCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No command logs yet, Sir. Say 'Hey Jarvis' or tap the Arc Reactor to issue your first directive.",
                        color = JarvisTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        } else {
            items(recentLogs) { log ->
                LogItemCard(log)
                Spacer(modifier = Modifier.height(8.dp))
            }
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun CommandChip(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .background(JarvisSurfaceCard, RoundedCornerShape(20.dp))
            .border(1.dp, JarvisGoldBorder, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = JarvisGold,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = JarvisGoldBright,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun LogItemCard(log: CommandLogEntity) {
    val timeFormat = SimpleDateFormat("h:mm:ss a", Locale.getDefault())
    val formattedTime = timeFormat.format(Date(log.timestamp))

    JarvisHudCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = if (log.isSpeakerVerified) JarvisGoldBorder else JarvisRed.copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "\"${log.rawQuery}\"",
                    color = JarvisTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = log.responseText,
                    color = JarvisTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                // Speaker verification badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (log.isSpeakerVerified) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (log.isSpeakerVerified) JarvisGreen else JarvisRed,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (log.isSpeakerVerified) "VERIFIED" else "REJECTED",
                        color = if (log.isSpeakerVerified) JarvisGreen else JarvisRed,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = formattedTime,
                    color = JarvisGoldDark,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}
