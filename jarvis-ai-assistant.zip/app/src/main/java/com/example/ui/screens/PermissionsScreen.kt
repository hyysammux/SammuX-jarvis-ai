package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.accessibility.JarvisAccessibilityService
import com.example.ui.JarvisScreen
import com.example.ui.components.JarvisHudCard
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBorder
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldDark
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisSurfaceCard
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun PermissionsScreen(
    onNavigate: (JarvisScreen) -> Unit
) {
    val context = LocalContext.current

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    var hasContactPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        )
    }

    var hasNotificationListenerAccess by remember {
        mutableStateOf(
            com.example.notifications.JarvisNotificationListener.isNotificationAccessGranted(context)
        )
    }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    val contactLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasContactPermission = permissions[Manifest.permission.READ_CONTACTS] == true
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "SECURITY PROTOCOL PERMISSIONS",
                color = JarvisGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.5.sp
            )

            Text(
                text = "Authorize Hardware Access",
                color = JarvisGoldBright,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )

            Text(
                text = "JARVIS enforces strict on-device sandboxing. All acoustic analysis and biometrics remain encrypted within your local hardware.",
                color = JarvisTextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                modifier = Modifier.padding(top = 6.dp, bottom = 20.dp)
            )

            // 1. Microphone Permission
            PermissionCard(
                title = "Acoustic Transducer (Microphone)",
                description = "Required for wake phrase detection ('Hey Jarvis'), speaker verification, and live voice commands.",
                isGranted = hasMicPermission,
                isRequired = true,
                onGrantClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Notification Permission
            PermissionCard(
                title = "Command HUD & Alerts",
                description = "Required to display ongoing status telemetry and deliver audio automation confirmations.",
                isGranted = hasNotificationPermission,
                isRequired = false,
                onGrantClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Telephony & Contacts for Voice Calling
            PermissionCard(
                title = "Contact Lookup & Voice Calling",
                description = "Required to understand commands like 'Call Butki' or 'Dial Mom' and place voice calls directly.",
                isGranted = hasContactPermission,
                isRequired = false,
                onGrantClick = {
                    contactLauncher.launch(
                        arrayOf(
                            Manifest.permission.READ_CONTACTS,
                            Manifest.permission.CALL_PHONE
                        )
                    )
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Notification Reader Service
            PermissionCard(
                title = "Notification Telemetry Reader",
                description = "Enables JARVIS to read your notifications aloud upon voice command ('Read notifications').",
                isGranted = hasNotificationListenerAccess,
                isRequired = false,
                buttonLabel = if (hasNotificationListenerAccess) "AUTHORIZED" else "ENABLE LISTENER",
                onGrantClick = {
                    com.example.notifications.JarvisNotificationListener.openNotificationAccessSettings(context)
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 5. Accessibility Service (Optional)
            PermissionCard(
                title = "System Automation (Optional)",
                description = "Allows JARVIS to execute global device gestures (Back, Home, Quick Settings) upon voice command.",
                isGranted = JarvisAccessibilityService.isServiceRunning(),
                isRequired = false,
                buttonLabel = if (JarvisAccessibilityService.isServiceRunning()) "ENABLED" else "CONFIGURE SETTINGS",
                onGrantClick = {
                    JarvisAccessibilityService.openAccessibilitySettings(context)
                }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                onNavigate(JarvisScreen.VOICE_ENROLLMENT)
            },
            enabled = hasMicPermission,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("continue_to_enrollment_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = JarvisGold,
                contentColor = JarvisBlack,
                disabledContainerColor = JarvisGoldDark.copy(alpha = 0.4f),
                disabledContentColor = JarvisTextSecondary.copy(alpha = 0.5f)
            )
        ) {
            Text(
                text = if (hasMicPermission) "PROCEED TO VOICE ENROLLMENT" else "GRANT MIC ACCESS TO CONTINUE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
private fun PermissionCard(
    title: String,
    description: String,
    isGranted: Boolean,
    isRequired: Boolean,
    buttonLabel: String = if (isGranted) "AUTHORIZED" else "AUTHORIZE ACCESS",
    onGrantClick: () -> Unit
) {
    JarvisHudCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = if (isGranted) JarvisGreen.copy(alpha = 0.6f) else JarvisGoldBorder
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    color = JarvisGoldBright,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                Box(
                    modifier = Modifier
                        .background(
                            if (isGranted) JarvisGreen.copy(alpha = 0.15f) else JarvisGoldDark.copy(alpha = 0.2f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isGranted) "GRANTED" else if (isRequired) "REQUIRED" else "OPTIONAL",
                        color = if (isGranted) JarvisGreen else if (isRequired) JarvisRed else JarvisGold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = description,
                color = JarvisTextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )

            if (!isGranted) {
                OutlinedButton(
                    onClick = onGrantClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisGold),
                    border = androidx.compose.foundation.BorderStroke(1.dp, JarvisGold)
                ) {
                    Text(
                        text = buttonLabel,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = JarvisGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Hardware link active & verified",
                        color = JarvisGreen,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
