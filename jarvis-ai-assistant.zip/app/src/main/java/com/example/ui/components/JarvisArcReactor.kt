package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JarvisBlack
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGoldBright
import com.example.ui.theme.JarvisGoldDark
import com.example.voice.VoiceAssistantState
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisArcReactor(
    state: VoiceAssistantState,
    audioRmsDb: Float,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactor_anim")

    // Slow continuous outer ring rotation
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rot"
    )

    // Counter-clockwise inner ring rotation
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rot"
    )

    // Pulse wave for core
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    // Audio reactivity factor
    val audioBoost = (audioRmsDb.coerceIn(0f, 15f) / 15f) * 0.25f
    val activeScale = if (state == VoiceAssistantState.LISTENING_FOR_COMMAND || state == VoiceAssistantState.SPEAKING_RESPONSE) {
        pulse + audioBoost
    } else {
        1f
    }

    val glowColor = when (state) {
        VoiceAssistantState.SPEAKER_VERIFIED -> JarvisCyan
        VoiceAssistantState.SPEAKER_REJECTED -> Color(0xFFFF3D00)
        VoiceAssistantState.LISTENING_FOR_COMMAND -> JarvisGoldBright
        VoiceAssistantState.PROCESSING_COMMAND -> JarvisCyan
        VoiceAssistantState.SPEAKING_RESPONSE -> JarvisGoldBright
        else -> JarvisGold
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val maxRadius = (this.size.minDimension / 2f) - 10f

            // 1. Ambient Glow Backing
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glowColor.copy(alpha = 0.35f * activeScale),
                        JarvisGoldDark.copy(alpha = 0.12f),
                        JarvisBlack.copy(alpha = 0f)
                    ),
                    center = center,
                    radius = maxRadius * 1.1f
                ),
                radius = maxRadius,
                center = center
            )

            // 2. Outer Technical Segmented Ring (Rotating clockwise)
            rotate(outerRotation, pivot = center) {
                drawCircle(
                    color = JarvisGoldDark,
                    radius = maxRadius * 0.95f,
                    center = center,
                    style = Stroke(
                        width = 3.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(25f, 15f, 10f, 15f), 0f)
                    )
                )

                // Outer Tick Markers (12 clock-like markers)
                for (i in 0 until 12) {
                    val angle = (i * 30) * (Math.PI / 180.0)
                    val startR = maxRadius * 0.88f
                    val endR = maxRadius * 0.94f
                    val startX = (center.x + startR * cos(angle)).toFloat()
                    val startY = (center.y + startR * sin(angle)).toFloat()
                    val endX = (center.x + endR * cos(angle)).toFloat()
                    val endY = (center.y + endR * sin(angle)).toFloat()

                    drawLine(
                        color = JarvisGoldBright,
                        start = Offset(startX, startY),
                        end = Offset(endX, endY),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            // 3. Middle Segmented Ring (Rotating counter-clockwise)
            rotate(innerRotation, pivot = center) {
                drawCircle(
                    color = glowColor.copy(alpha = 0.8f),
                    radius = maxRadius * 0.72f,
                    center = center,
                    style = Stroke(
                        width = 4.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(45f, 20f), 0f)
                    )
                )

                // 6 Concentric nodes
                for (i in 0 until 6) {
                    val angle = (i * 60) * (Math.PI / 180.0)
                    val r = maxRadius * 0.72f
                    val x = (center.x + r * cos(angle)).toFloat()
                    val y = (center.y + r * sin(angle)).toFloat()
                    drawCircle(
                        color = JarvisGoldBright,
                        radius = 4.dp.toPx(),
                        center = Offset(x, y)
                    )
                }
            }

            // 4. Inner Ring with Solid Metallic Gold
            drawCircle(
                color = JarvisGold,
                radius = maxRadius * 0.50f,
                center = center,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // 5. Central Reactor Core (Pulsing dynamically)
            val coreRadius = (maxRadius * 0.38f) * activeScale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glowColor,
                        JarvisGoldDark,
                        JarvisBlack
                    ),
                    center = center,
                    radius = coreRadius
                ),
                radius = coreRadius,
                center = center
            )

            // Center Energy Point
            drawCircle(
                color = Color.White,
                radius = 6.dp.toPx() * activeScale,
                center = center
            )
        }
    }
}
