package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JARVIS Black + Gold Premium Palette
val JarvisBlack = Color(0xFF07080B)
val JarvisBlackElevated = Color(0xFF0E1015)
val JarvisSurface = Color(0xFF13151D)
val JarvisSurfaceCard = Color(0xFF191C26)
val JarvisSurfaceLight = Color(0xFF222634)

// Gold Accents & Highlights
val JarvisGold = Color(0xFFD4AF37)
val JarvisGoldBright = Color(0xFFFFDF73)
val JarvisGoldMuted = Color(0xFFAA8C2C)
val JarvisGoldDark = Color(0xFF5E4D19)
val JarvisGoldContainer = Color(0xFF27210D)
val JarvisGoldBorder = Color(0xFF6B5823)

// Status & Holographic Accents
val JarvisCyan = Color(0xFF00E5FF)
val JarvisGreen = Color(0xFF00E676)
val JarvisRed = Color(0xFFFF5252)
val JarvisBlue = Color(0xFF2979FF)

// Text Colors
val JarvisTextPrimary = Color(0xFFF7F8FA)
val JarvisTextSecondary = Color(0xFFA5A8B8)
val JarvisTextMuted = Color(0xFF696D80)
val JarvisTextGold = Color(0xFFFFE082)
