package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.example.security.LanguagePreference
import com.example.security.SecureStorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiAiService(private val secureStorage: SecureStorageManager) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun queryGemini(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = secureStorage.customApiKey
            ?.takeIf { it.isNotBlank() }
            ?: BuildConfig.GEMINI_API_KEY

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getOfflineJarvisResponse(prompt)
        }

        try {
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val systemInstructionText = """
                You are J.A.R.V.I.S., the autonomous AI assistant.
                You are loyal, sophisticated, highly intelligent, and speak with courteous poise.
                Always address the user respectfully as 'Sir'.
                Keep answers concise, direct, and under 3 sentences so they can be spoken clearly via Text-To-Speech.
                Respond in the language of the prompt (English, Hindi, or Hinglish).
            """.trimIndent()

            val jsonBody = JSONObject().apply {
                // System Instruction
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", systemInstructionText))
                    })
                })

                // Contents
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                })

                // Generation Config
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 250)
                })
            }

            val request = Request.Builder()
                .url(endpoint)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val jsonResponse = JSONObject(responseBody)
                val candidates = jsonResponse.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val content = firstCandidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val text = parts?.optJSONObject(0)?.optString("text")

                if (!text.isNullOrBlank()) {
                    return@withContext text.trim()
                }
            } else {
                Log.w(TAG, "Gemini API error code: ${response.code}, body: $responseBody")
            }

            getOfflineJarvisResponse(prompt)
        } catch (e: Exception) {
            Log.e(TAG, "Gemini call failed: ${e.message}")
            getOfflineJarvisResponse(prompt)
        }
    }

    private fun getOfflineJarvisResponse(prompt: String): String {
        val p = prompt.lowercase()
        val lang = secureStorage.languagePreference

        return when {
            p.contains("who are you") || p.contains("tum kaun ho") || p.contains("koun ho") -> {
                if (lang == LanguagePreference.HINDI) {
                    "Main J.A.R.V.I.S. hoon Sir, aapka autonomous personal AI assistant. Main aapki har command execute karne ke liye taiyaar hoon."
                } else {
                    "I am J.A.R.V.I.S., your autonomous AI assistant, Sir. Ready to assist you with hardware controls, routines, and intelligence."
                }
            }
            p.contains("who created you") || p.contains("kisne banaya") -> {
                "I was engineered as a high-precision AI assistant inspired by Stark Industries architecture, Sir."
            }
            p.contains("how are you") || p.contains("kaise ho") -> {
                "All systems are operating at peak efficiency, Sir. Ready for your instructions."
            }
            p.contains("joke") || p.contains("chutkula") -> {
                "Why did the neural network cross the road? To optimize its loss function on the other side, Sir."
            }
            p.contains("iron man") || p.contains("tony stark") -> {
                "Mr. Stark is always monitoring telemetry from the penthouse, Sir."
            }
            else -> {
                if (lang == LanguagePreference.HINDI) {
                    "Ji Sir, maine aapka prashna note kar liya hai: '$prompt'. Sabhi systems taiyaar hain."
                } else {
                    "Acknowledged, Sir. Querying global knowledge nodes for '$prompt'. Systems stand ready."
                }
            }
        }
    }

    companion object {
        private const val TAG = "GeminiAiService"
    }
}
