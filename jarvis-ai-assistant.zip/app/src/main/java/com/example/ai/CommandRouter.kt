package com.example.ai

import com.example.automation.ContactActionHandler
import com.example.automation.ContactActionResult
import com.example.automation.DeviceController
import com.example.automation.NotificationDraftResult
import com.example.automation.NotificationReplyHandler
import com.example.automation.RoutineManager
import com.example.automation.SnapchatActionResult
import com.example.automation.SnapchatAutomationHandler
import com.example.automation.WhatsAppActionResult
import com.example.automation.WhatsAppAutomationHandler
import com.example.automation.YouTubeActionResult
import com.example.automation.YouTubeAutomationHandler
import com.example.automation.YouTubeSubAction
import com.example.data.JarvisRepository

class CommandRouter(
    private val deviceController: DeviceController,
    private val routineManager: RoutineManager,
    private val repository: JarvisRepository,
    private val geminiService: GeminiAiService,
    private val contactActionHandler: ContactActionHandler,
    private val snapchatHandler: SnapchatAutomationHandler,
    private val whatsAppHandler: WhatsAppAutomationHandler,
    private val youTubeHandler: YouTubeAutomationHandler,
    private val notificationReplyHandler: NotificationReplyHandler
) {

    suspend fun routeAndExecute(
        intent: AiIntent,
        rawQuery: String,
        isSpeakerVerified: Boolean = true
    ): CommandExecutionResult {
        val startTime = System.currentTimeMillis()

        return when (intent) {
            is AiIntent.Flashlight -> {
                val result = deviceController.toggleFlashlight(intent.enable)
                val duration = System.currentTimeMillis() - startTime
                if (result.isSuccess) {
                    val msg = result.getOrNull() ?: "Flashlight state updated, Sir."
                    CommandExecutionResult(
                        spokenResponse = msg,
                        visualDisplay = msg,
                        isSuccess = true,
                        intentName = "Hardware • Flashlight",
                        executionTimeMs = duration
                    )
                } else {
                    val err = result.exceptionOrNull()?.message ?: "Flashlight hardware error"
                    CommandExecutionResult(
                        spokenResponse = "I was unable to toggle the flashlight, Sir. $err",
                        visualDisplay = "Error: $err",
                        isSuccess = false,
                        intentName = "Hardware • Flashlight",
                        executionTimeMs = duration
                    )
                }
            }

            is AiIntent.Volume -> {
                val result = deviceController.adjustVolume(intent.direction)
                val duration = System.currentTimeMillis() - startTime
                val msg = result.getOrNull() ?: "Volume adjustment failed"
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = result.isSuccess,
                    intentName = "Audio • Volume Control",
                    executionTimeMs = duration
                )
            }

            is AiIntent.BatteryStatus -> {
                val msg = deviceController.getBatteryStatus()
                val duration = System.currentTimeMillis() - startTime
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = true,
                    intentName = "Diagnostics • Power Level",
                    executionTimeMs = duration
                )
            }

            is AiIntent.TimeDate -> {
                val msg = deviceController.getCurrentTimeAndDate()
                val duration = System.currentTimeMillis() - startTime
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = true,
                    intentName = "System • Chronometer",
                    executionTimeMs = duration
                )
            }

            is AiIntent.LaunchApp -> {
                val result = deviceController.launchApplication(intent.target)
                val duration = System.currentTimeMillis() - startTime
                val msg = result.getOrNull() ?: (result.exceptionOrNull()?.message ?: "Application launch failed")
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = result.isSuccess,
                    intentName = "Automation • App Launch",
                    executionTimeMs = duration
                )
            }

            is AiIntent.DynamicAppLaunch -> {
                val result = deviceController.launchDynamicApp(intent.appName)
                val duration = System.currentTimeMillis() - startTime
                val msg = result.getOrNull() ?: (result.exceptionOrNull()?.message ?: "App launch blocked")
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = result.isSuccess,
                    intentName = "Automation • Dynamic App Launcher",
                    executionTimeMs = duration
                )
            }

            // Snapchat Assistant (Part 4)
            is AiIntent.SnapchatAction -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = snapchatHandler.executeAction(intent.action, intent.param)) {
                    is SnapchatActionResult.Success -> {
                        CommandExecutionResult(
                            spokenResponse = result.spokenResponse,
                            visualDisplay = result.visualDetails,
                            isSuccess = true,
                            intentName = "Snapchat • ${intent.action}",
                            executionTimeMs = duration
                        )
                    }
                    is SnapchatActionResult.AppNotInstalled -> {
                        CommandExecutionResult(
                            spokenResponse = result.message,
                            visualDisplay = "Snapchat Not Installed",
                            isSuccess = false,
                            intentName = "Snapchat • Not Installed",
                            executionTimeMs = duration
                        )
                    }
                    is SnapchatActionResult.PolicyRestriction -> {
                        CommandExecutionResult(
                            spokenResponse = result.explanation,
                            visualDisplay = "Security Policy: Android Sandbox Restriction",
                            isSuccess = false,
                            intentName = "Snapchat • Policy Restriction",
                            executionTimeMs = duration
                        )
                    }
                    is SnapchatActionResult.ActionFailed -> {
                        CommandExecutionResult(
                            spokenResponse = result.error,
                            visualDisplay = "Snapchat Error: ${result.error}",
                            isSuccess = false,
                            intentName = "Snapchat • Action Failed",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            // WhatsApp Messaging & Calling (Part 5)
            is AiIntent.WhatsAppMessage -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = whatsAppHandler.sendWhatsAppMessage(intent.recipient, intent.message, isSpeakerVerified)) {
                    is WhatsAppActionResult.Success -> {
                        CommandExecutionResult(
                            spokenResponse = result.message,
                            visualDisplay = "WhatsApp Message: ${result.recipient}\n'${result.text}'",
                            isSuccess = true,
                            intentName = "WhatsApp • Message Dispatch",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.VerificationRequired -> {
                        CommandExecutionResult(
                            spokenResponse = result.reason,
                            visualDisplay = "Security Alert: Voice Verification Required",
                            isSuccess = false,
                            intentName = "WhatsApp • Voice Security",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.ContactNotFound -> {
                        CommandExecutionResult(
                            spokenResponse = result.explanation,
                            visualDisplay = "Contact Missing: '${result.query}'",
                            isSuccess = false,
                            intentName = "WhatsApp • Contact Not Found",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.AppNotInstalled -> {
                        CommandExecutionResult(
                            spokenResponse = result.message,
                            visualDisplay = "WhatsApp Not Installed",
                            isSuccess = false,
                            intentName = "WhatsApp • Missing Package",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.Failed -> {
                        CommandExecutionResult(
                            spokenResponse = result.error,
                            visualDisplay = "Error: ${result.error}",
                            isSuccess = false,
                            intentName = "WhatsApp • Dispatch Error",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            is AiIntent.WhatsAppCall -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = whatsAppHandler.callContactWhatsApp(intent.recipient, isSpeakerVerified)) {
                    is WhatsAppActionResult.Success -> {
                        CommandExecutionResult(
                            spokenResponse = result.message,
                            visualDisplay = "WhatsApp Calling: ${result.recipient}",
                            isSuccess = true,
                            intentName = "WhatsApp • Voice Call",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.VerificationRequired -> {
                        CommandExecutionResult(
                            spokenResponse = result.reason,
                            visualDisplay = "Security Alert: Voice Verification Failed",
                            isSuccess = false,
                            intentName = "WhatsApp • Security Blocked",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.ContactNotFound -> {
                        CommandExecutionResult(
                            spokenResponse = result.explanation,
                            visualDisplay = "Contact Missing: '${result.query}'",
                            isSuccess = false,
                            intentName = "WhatsApp • Contact Not Found",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.AppNotInstalled -> {
                        CommandExecutionResult(
                            spokenResponse = result.message,
                            visualDisplay = "WhatsApp Not Installed",
                            isSuccess = false,
                            intentName = "WhatsApp • Missing Package",
                            executionTimeMs = duration
                        )
                    }
                    is WhatsAppActionResult.Failed -> {
                        CommandExecutionResult(
                            spokenResponse = result.error,
                            visualDisplay = "Error: ${result.error}",
                            isSuccess = false,
                            intentName = "WhatsApp • Call Error",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            // YouTube Automation (Part 6)
            is AiIntent.YouTubeControl -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = youTubeHandler.executeAction(intent.action, intent.param)) {
                    is YouTubeActionResult.Success -> {
                        CommandExecutionResult(
                            spokenResponse = result.spokenResponse,
                            visualDisplay = result.visualDetails,
                            isSuccess = true,
                            intentName = "YouTube • ${intent.action}",
                            executionTimeMs = duration
                        )
                    }
                    is YouTubeActionResult.PolicyExplanation -> {
                        CommandExecutionResult(
                            spokenResponse = result.explanation,
                            visualDisplay = "Policy Notice: Direct User Interaction Required",
                            isSuccess = true,
                            intentName = "YouTube • Policy Notice",
                            executionTimeMs = duration
                        )
                    }
                    is YouTubeActionResult.Failed -> {
                        CommandExecutionResult(
                            spokenResponse = result.error,
                            visualDisplay = "YouTube Error: ${result.error}",
                            isSuccess = false,
                            intentName = "YouTube • Execution Error",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            is AiIntent.YouTubeSearch -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = youTubeHandler.executeAction(YouTubeSubAction.SEARCH, intent.query)) {
                    is YouTubeActionResult.Success -> {
                        CommandExecutionResult(
                            spokenResponse = result.spokenResponse,
                            visualDisplay = result.visualDetails,
                            isSuccess = true,
                            intentName = "YouTube • Search",
                            executionTimeMs = duration
                        )
                    }
                    else -> {
                        CommandExecutionResult(
                            spokenResponse = "YouTube search failed, Sir.",
                            visualDisplay = "YouTube Search Failed",
                            isSuccess = false,
                            intentName = "YouTube • Search",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            // Notification Reader & Interactive Drafts (Part 7)
            is AiIntent.ReadNotifications -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = notificationReplyHandler.readNotificationsAndPrompt()) {
                    is NotificationDraftResult.ReadComplete -> {
                        CommandExecutionResult(
                            spokenResponse = result.speech,
                            visualDisplay = "Notification Telemetry Readout:\n${result.speech}",
                            isSuccess = true,
                            intentName = "Telemetry • Notifications",
                            executionTimeMs = duration
                        )
                    }
                    else -> {
                        val speech = deviceController.readNotifications()
                        CommandExecutionResult(
                            spokenResponse = speech,
                            visualDisplay = speech,
                            isSuccess = true,
                            intentName = "Telemetry • Notifications",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            is AiIntent.DraftNotificationReply -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = notificationReplyHandler.prepareDraft(intent.message, intent.targetSender)) {
                    is NotificationDraftResult.DraftCreated -> {
                        CommandExecutionResult(
                            spokenResponse = result.speech,
                            visualDisplay = "Pending Draft:\nRecipient: ${result.draft.senderName} (${result.draft.appName})\nMessage: '${result.draft.draftText}'\n\nWaiting for confirmation...",
                            isSuccess = true,
                            intentName = "Notification • Reply Drafted",
                            executionTimeMs = duration
                        )
                    }
                    is NotificationDraftResult.NoTargetNotification -> {
                        CommandExecutionResult(
                            spokenResponse = result.speech,
                            visualDisplay = result.speech,
                            isSuccess = false,
                            intentName = "Notification • No Active Alert",
                            executionTimeMs = duration
                        )
                    }
                    else -> {
                        CommandExecutionResult(
                            spokenResponse = "Unable to prepare reply draft, Sir.",
                            visualDisplay = "Draft Error",
                            isSuccess = false,
                            intentName = "Notification • Draft Error",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            is AiIntent.ConfirmPendingAction -> {
                val duration = System.currentTimeMillis() - startTime
                when (val result = notificationReplyHandler.confirmAndSend()) {
                    is NotificationDraftResult.ReplySent -> {
                        CommandExecutionResult(
                            spokenResponse = result.speech,
                            visualDisplay = "Reply Dispatched to ${result.recipient}",
                            isSuccess = true,
                            intentName = "Notification • Reply Transmitted",
                            executionTimeMs = duration
                        )
                    }
                    is NotificationDraftResult.UnsupportedInlineReply -> {
                        CommandExecutionResult(
                            spokenResponse = result.speech,
                            visualDisplay = "Inline Reply Not Supported: App Launched",
                            isSuccess = true,
                            intentName = "Notification • App Relay",
                            executionTimeMs = duration
                        )
                    }
                    is NotificationDraftResult.NoTargetNotification -> {
                        CommandExecutionResult(
                            spokenResponse = "No pending draft or confirmation requested, Sir.",
                            visualDisplay = "No Pending Action",
                            isSuccess = false,
                            intentName = "Control • No Action Pending",
                            executionTimeMs = duration
                        )
                    }
                    else -> {
                        CommandExecutionResult(
                            spokenResponse = "Confirmation handled, Sir.",
                            visualDisplay = "Confirmed",
                            isSuccess = true,
                            intentName = "Control • Confirmed",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            is AiIntent.CancelPendingAction -> {
                val duration = System.currentTimeMillis() - startTime
                val result = notificationReplyHandler.cancelDraft()
                CommandExecutionResult(
                    spokenResponse = (result as? NotificationDraftResult.DraftCancelled)?.speech ?: "Action cancelled, Sir.",
                    visualDisplay = "Action Cancelled by User",
                    isSuccess = true,
                    intentName = "Control • Cancelled",
                    executionTimeMs = duration
                )
            }

            is AiIntent.InstagramAction -> {
                val result = deviceController.openInstagram(intent.profileOrQuery)
                val duration = System.currentTimeMillis() - startTime
                val msg = result.getOrNull() ?: "Instagram navigation completed, Sir."
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = if (intent.profileOrQuery != null) "Instagram Profile: @${intent.profileOrQuery}" else "Instagram Launched",
                    isSuccess = result.isSuccess,
                    intentName = "Social • Instagram Navigation",
                    executionTimeMs = duration
                )
            }

            is AiIntent.OpenDeveloperProfile -> {
                val duration = System.currentTimeMillis() - startTime
                val result = deviceController.openDeveloperInstagram()
                val spoken = "I was developed by Sammu. Please make sure to follow Sammu on Instagram at @hyy_sammu.x. Opening the developer profile now, Sir!"
                CommandExecutionResult(
                    spokenResponse = spoken,
                    visualDisplay = "DEVELOPER: SAMMU\nINSTAGRAM: @hyy_sammu.x\nURL: https://www.instagram.com/hyy_sammu.x?stkn=MXZjb2hydTNsc3p3NQ==",
                    isSuccess = result.isSuccess,
                    intentName = "Developer • Sammu Instagram Profile",
                    executionTimeMs = duration
                )
            }

            is AiIntent.CallContact -> {
                val duration = System.currentTimeMillis() - startTime
                when (val callResult = contactActionHandler.callContactOrNumber(intent.targetNameOrNumber)) {
                    is ContactActionResult.Success -> {
                        CommandExecutionResult(
                            spokenResponse = callResult.message,
                            visualDisplay = "Placing Call: ${callResult.contactName} (${callResult.phoneNumber})",
                            isSuccess = true,
                            intentName = "Telephony • Voice Call",
                            executionTimeMs = duration
                        )
                    }
                    is ContactActionResult.ActionBlocked -> {
                        CommandExecutionResult(
                            spokenResponse = callResult.reason,
                            visualDisplay = "Call Blocked: ${callResult.reason}",
                            isSuccess = false,
                            intentName = "Telephony • Permission Blocked",
                            executionTimeMs = duration
                        )
                    }
                    is ContactActionResult.NotFound -> {
                        CommandExecutionResult(
                            spokenResponse = callResult.explanation,
                            visualDisplay = "Contact Not Found: '${callResult.query}'",
                            isSuccess = false,
                            intentName = "Telephony • Contact Lookup",
                            executionTimeMs = duration
                        )
                    }
                }
            }

            is AiIntent.SaveNote -> {
                repository.saveNote(intent.title, intent.content)
                val duration = System.currentTimeMillis() - startTime
                val msg = "Note saved to secure memory vault: '${intent.title}', Sir."
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = "Note Recorded: ${intent.title}\n${intent.content}",
                    isSuccess = true,
                    intentName = "Memory • Note Vault",
                    executionTimeMs = duration
                )
            }

            is AiIntent.RunSmartRoutine -> {
                val msg = routineManager.executeRoutine(intent.actionType)
                val duration = System.currentTimeMillis() - startTime
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = true,
                    intentName = "Routine • Protocol Execution",
                    executionTimeMs = duration
                )
            }

            is AiIntent.WebSearch -> {
                val result = deviceController.openWebSearch(intent.query)
                val duration = System.currentTimeMillis() - startTime
                val msg = result.getOrNull() ?: "Web search initiated, Sir."
                CommandExecutionResult(
                    spokenResponse = msg,
                    visualDisplay = msg,
                    isSuccess = result.isSuccess,
                    intentName = "Network • Web Intelligence",
                    executionTimeMs = duration
                )
            }

            is AiIntent.ConversationalAi -> {
                val reply = geminiService.queryGemini(intent.prompt)
                val duration = System.currentTimeMillis() - startTime
                CommandExecutionResult(
                    spokenResponse = reply,
                    visualDisplay = reply,
                    isSuccess = true,
                    intentName = "Neural • Gemini Intelligence",
                    executionTimeMs = duration
                )
            }

            is AiIntent.Unsupported -> {
                val duration = System.currentTimeMillis() - startTime
                CommandExecutionResult(
                    spokenResponse = intent.reason,
                    visualDisplay = "Unsupported Action: ${intent.rawQuery}\nReason: ${intent.reason}",
                    isSuccess = false,
                    intentName = "Security • Policy Restriction",
                    executionTimeMs = duration
                )
            }
        }
    }
}
