package com.example.ai

import com.example.automation.AppTarget
import com.example.automation.SnapchatSubAction
import com.example.automation.VolumeDirection
import com.example.automation.YouTubeSubAction

sealed class AiIntent {
    data class Flashlight(val enable: Boolean?) : AiIntent()
    data class Volume(val direction: VolumeDirection) : AiIntent()
    object BatteryStatus : AiIntent()
    object TimeDate : AiIntent()
    data class LaunchApp(val target: AppTarget) : AiIntent()
    data class DynamicAppLaunch(val appName: String) : AiIntent()
    data class CallContact(val targetNameOrNumber: String) : AiIntent()
    data class YouTubeSearch(val query: String) : AiIntent()
    data class YouTubeControl(val action: YouTubeSubAction, val param: String? = null) : AiIntent()
    data class InstagramAction(val profileOrQuery: String?) : AiIntent()
    data class SnapchatAction(val action: SnapchatSubAction, val param: String? = null) : AiIntent()
    data class WhatsAppMessage(val recipient: String, val message: String) : AiIntent()
    data class WhatsAppCall(val recipient: String) : AiIntent()
    object ReadNotifications : AiIntent()
    data class DraftNotificationReply(val message: String, val targetSender: String? = null) : AiIntent()
    object ConfirmPendingAction : AiIntent()
    object CancelPendingAction : AiIntent()
    data class SaveNote(val title: String, val content: String) : AiIntent()
    data class RunSmartRoutine(val actionType: String) : AiIntent()
    data class WebSearch(val query: String) : AiIntent()
    data class ConversationalAi(val prompt: String) : AiIntent()
    object OpenDeveloperProfile : AiIntent()
    data class Unsupported(val rawQuery: String, val reason: String) : AiIntent()
}

data class CommandExecutionResult(
    val spokenResponse: String,
    val visualDisplay: String,
    val isSuccess: Boolean,
    val intentName: String,
    val executionTimeMs: Long
)
