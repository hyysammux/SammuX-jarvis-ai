package com.example.ai

import com.example.automation.AppTarget
import com.example.automation.SnapchatSubAction
import com.example.automation.VolumeDirection
import com.example.automation.YouTubeSubAction

object IntentClassifier {

    fun classify(query: String): AiIntent {
        val q = query.lowercase().trim()
        val cleanQ = q.replace(",", "").replace(".", "").replace("!", "").replace("?", "").replace("'", "").trim()

        // 0. User Confirmation / Cancellation Flow for Drafts & Sensitive Actions
        if (cleanQ == "yes" || cleanQ == "confirm" || cleanQ == "send" || cleanQ == "send it" || cleanQ == "yes send it" ||
            cleanQ == "yes send" || cleanQ == "confirm sending" || cleanQ == "haan bhej do" || cleanQ == "haan send karo" ||
            cleanQ == "bhej do" || cleanQ == "proceed" || cleanQ == "yes sir"
        ) {
            return AiIntent.ConfirmPendingAction
        }
        if (cleanQ == "no" || cleanQ == "cancel" || cleanQ == "discard" || cleanQ == "dont send" ||
            cleanQ == "mat bhejo" || cleanQ == "cancel karo" || cleanQ == "abort" || cleanQ == "stop"
        ) {
            return AiIntent.CancelPendingAction
        }

        // 1. Interactive Notification Reply Drafting ("Reply I'm in a meeting", "Draft reply: I will call you back", "क्या मैं रिप्लाई ड्राफ्ट करूँ?")
        if (q.startsWith("reply ") || q.startsWith("draft reply ") || q.startsWith("draft ") ||
            q.startsWith("reply draft karo ") || q.startsWith("jawab do ")
        ) {
            val text = q
                .removePrefix("draft reply to")
                .removePrefix("draft reply")
                .removePrefix("reply to")
                .removePrefix("reply draft karo")
                .removePrefix("reply")
                .removePrefix("draft")
                .removePrefix("jawab do")
                .trim()
                .removePrefix(":")
                .trim()

            if (text.isNotBlank()) {
                return AiIntent.DraftNotificationReply(text)
            }
        }

        // 2. Notification Reading ("Read notifications", "Notification padho", "Check alerts")
        if (containsAny(q, "read notification", "read notifications", "notification padho", "notifications padho",
                "check notification", "check notifications", "read my messages", "read alerts", "read notice", "kya notification hai")
        ) {
            return AiIntent.ReadNotifications
        }

        // 3. Snapchat Assistant Modules (Part 4)
        if (containsAny(q, "snapchat", "snap chat", "snaps")) {
            // Restriction check: secret screenshot, eavesdropping, background hacking
            if (containsAny(q, "secret", "hack", "spy", "without notice", "steal", "read private snaps")) {
                return AiIntent.SnapchatAction(SnapchatSubAction.RESTRICTED_ACTION)
            }
            if (containsAny(q, "open my chats", "my chats", "chats", "chat screen", "messages")) {
                return AiIntent.SnapchatAction(SnapchatSubAction.OPEN_CHATS)
            }
            if (containsAny(q, "stories screen", "open stories", "stories", "discover")) {
                return AiIntent.SnapchatAction(SnapchatSubAction.OPEN_STORIES)
            }
            if (containsAny(q, "open camera", "camera", "take snap", "viewfinder")) {
                return AiIntent.SnapchatAction(SnapchatSubAction.OPEN_CAMERA)
            }
            if (containsAny(q, "profile", "my profile", "user profile", "account")) {
                val user = q.substringAfter("profile of", "")
                    .ifEmpty { q.substringAfter("profile", "") }
                    .trim().removePrefix("@")
                return AiIntent.SnapchatAction(SnapchatSubAction.OPEN_PROFILE, user.ifBlank { null })
            }
            if (containsAny(q, "settings", "setting", "preference")) {
                return AiIntent.SnapchatAction(SnapchatSubAction.SETTINGS)
            }
            if (containsAny(q, "search", "find contact", "dhoondo", "look up")) {
                val searchTarget = q.substringAfter("search", "")
                    .replace("on snapchat", "")
                    .replace("in snapchat", "")
                    .replace("for", "")
                    .trim()
                return AiIntent.SnapchatAction(SnapchatSubAction.SEARCH_CONTACT, searchTarget.ifBlank { null })
            }
            return AiIntent.SnapchatAction(SnapchatSubAction.OPEN_APP)
        }

        // 4. WhatsApp & Communication Controls (Part 5)
        if (containsAny(q, "whatsapp", "whats app", "wa ")) {
            if (q.contains("call")) {
                val target = q.substringAfter("call", "")
                    .replace("on whatsapp", "")
                    .replace("in whatsapp", "")
                    .replace("ko", "")
                    .trim()
                if (target.isNotBlank()) {
                    return AiIntent.WhatsAppCall(target)
                }
            }
            // Message to contact on WhatsApp ("Send WhatsApp message to Mom I will be late")
            val targetAndMsg = q.removePrefix("send whatsapp message to")
                .removePrefix("send whatsapp to")
                .removePrefix("whatsapp message to")
                .removePrefix("whatsapp to")
                .removePrefix("message to")
                .removePrefix("whatsapp")
                .trim()

            // Split into recipient and text
            val words = targetAndMsg.split(" ")
            if (words.size >= 2) {
                val recipient = words[0].trim()
                val messageText = targetAndMsg.substringAfter(recipient).trim()
                if (recipient.isNotBlank() && messageText.isNotBlank()) {
                    return AiIntent.WhatsAppMessage(recipient, messageText)
                }
            }
            return AiIntent.LaunchApp(AppTarget.WHATSAPP)
        }

        // 5. YouTube Automation (Part 6)
        if (containsAny(q, "youtube")) {
            if (containsAny(q, "play first video", "play first", "pehla video chalao")) {
                return AiIntent.YouTubeControl(YouTubeSubAction.PLAY_FIRST)
            }
            if (containsAny(q, "pause", "resume", "play/pause", "rok do", "chalu karo")) {
                return AiIntent.YouTubeControl(YouTubeSubAction.PAUSE_RESUME)
            }
            if (containsAny(q, "next video", "next track", "skip video", "agla video", "next")) {
                return AiIntent.YouTubeControl(YouTubeSubAction.NEXT_VIDEO)
            }
            if (containsAny(q, "subscribe", "channel subscribe")) {
                return AiIntent.YouTubeControl(YouTubeSubAction.SUBSCRIBE)
            }
            if (containsAny(q, "search", "play", "dhoondo", "chalao")) {
                val searchContent = q
                    .replace("search on youtube for", "")
                    .replace("search on youtube", "")
                    .replace("search youtube for", "")
                    .replace("search youtube", "")
                    .replace("play on youtube", "")
                    .replace("play youtube", "")
                    .replace("youtube search", "")
                    .replace("search for", "")
                    .replace("search", "")
                    .replace("play", "")
                    .replace("on youtube", "")
                    .replace("in youtube", "")
                    .replace("youtube", "")
                    .trim()

                if (searchContent.isNotBlank()) {
                    return AiIntent.YouTubeControl(YouTubeSubAction.SEARCH, searchContent)
                }
            }
            return AiIntent.YouTubeControl(YouTubeSubAction.OPEN)
        }

        // Global Media Playback controls (when "Pause" / "Resume" / "Next video" is said standalone)
        if (q == "pause" || q == "resume" || q == "pause video" || q == "resume video" || q == "pause music" || q == "resume music") {
            return AiIntent.YouTubeControl(YouTubeSubAction.PAUSE_RESUME)
        }
        if (q == "next video" || q == "skip video" || q == "next song" || q == "next track") {
            return AiIntent.YouTubeControl(YouTubeSubAction.NEXT_VIDEO)
        }

        // 6. Cellular Phone Call & Contact Actions ("Call Butki", "Call Mom", "Dial 9876543210")
        if (q.startsWith("call ") || q.startsWith("dial ") || q.startsWith("phone ") ||
            q.contains("ko call lagao") || q.contains("ko call karo") || q.contains("ko phone karo")
        ) {
            val contactName = q
                .removePrefix("call to")
                .removePrefix("call")
                .removePrefix("dial")
                .removePrefix("phone")
                .replace("ko call lagao", "")
                .replace("ko call karo", "")
                .replace("ko phone karo", "")
                .trim()

            if (contactName.isNotEmpty()) {
                return AiIntent.CallContact(contactName)
            }
        }

        // 7. Developer Attribution & Instagram Follow ("Developed by sammu", "Who is your developer", "Developer kaun hai", "Instagram ID")
        if (containsAny(q, "sammu", "samu", "who made you", "who developed you", "who created you",
                "kisne banaya", "developer kaun hai", "creator kaun hai", "follow developer", "developer instagram",
                "sammu instagram", "developer id", "hyy_sammu", "follow on instagram", "follow sammu") ||
            (q.contains("developer") && !q.contains("option"))
        ) {
            return AiIntent.OpenDeveloperProfile
        }

        // 8. Instagram Actions ("Open Instagram", "Instagram profile of [user]")
        if (containsAny(q, "instagram", "insta")) {
            if (q.contains("profile") || q.contains("user") || q.contains("account") || q.contains("id")) {
                val user = q
                    .substringAfter("profile of", "")
                    .ifEmpty { q.substringAfter("profile", "") }
                    .ifEmpty { q.substringAfter("user", "") }
                    .ifEmpty { q.substringAfter("account", "") }
                    .trim()
                    .removePrefix("@")

                if (user.isNotBlank()) {
                    return AiIntent.InstagramAction(user)
                }
            }
            return AiIntent.InstagramAction(null)
        }

        // 8. App Launching - Known Fast Targets
        if (containsAny(q, "open camera", "camera kholo", "photo khicho", "take photo", "camera on")) {
            return AiIntent.LaunchApp(AppTarget.CAMERA)
        }
        if (containsAny(q, "open spotify", "spotify kholo", "spotify open", "music chalao")) {
            return AiIntent.LaunchApp(AppTarget.SPOTIFY)
        }
        if (containsAny(q, "open settings", "settings kholo", "system settings")) {
            return AiIntent.LaunchApp(AppTarget.SETTINGS)
        }
        if (containsAny(q, "open browser", "chrome kholo", "open chrome", "internet kholo")) {
            return AiIntent.LaunchApp(AppTarget.BROWSER)
        }
        if (containsAny(q, "open maps", "maps kholo", "navigation", "google maps")) {
            return AiIntent.LaunchApp(AppTarget.MAPS)
        }
        if (containsAny(q, "open dialer", "open phone", "phone kholo", "dialer kholo")) {
            return AiIntent.LaunchApp(AppTarget.PHONE)
        }

        // 9. Generic Dynamic App Launcher ("Open [AppName]", "[AppName] kholo")
        if (q.startsWith("open ") || q.endsWith(" kholo") || q.endsWith(" open")) {
            val appName = q
                .removePrefix("open")
                .removeSuffix("kholo")
                .removeSuffix("open")
                .trim()

            if (appName.isNotEmpty() && appName.length > 2) {
                return AiIntent.DynamicAppLaunch(appName)
            }
        }

        // 10. Flashlight / Torch Controls
        if (containsAny(q, "turn on flashlight", "torch on", "flashlight on", "torch chalu", "lights on", "torch on karo", "flashlight jalao", "torch jalao")) {
            return AiIntent.Flashlight(true)
        }
        if (containsAny(q, "turn off flashlight", "torch off", "flashlight off", "torch band", "lights off", "torch band karo", "flashlight bujhao")) {
            return AiIntent.Flashlight(false)
        }
        if (containsAny(q, "flashlight", "torch", "light")) {
            return AiIntent.Flashlight(null)
        }

        // 11. Volume Controls
        if (containsAny(q, "volume up", "increase volume", "sound badhao", "awaaz badhao", "loud", "sound up", "volume increase")) {
            return AiIntent.Volume(VolumeDirection.UP)
        }
        if (containsAny(q, "volume down", "decrease volume", "sound kam", "awaaz kam", "quiet", "volume lower")) {
            return AiIntent.Volume(VolumeDirection.DOWN)
        }
        if (containsAny(q, "mute", "silence", "shant raho", "awaaz band", "quiet mode")) {
            return AiIntent.Volume(VolumeDirection.MUTE)
        }
        if (containsAny(q, "max volume", "full volume", "full sound", "full awaaz")) {
            return AiIntent.Volume(VolumeDirection.MAX)
        }

        // 12. Battery & Power Telemetry
        if (containsAny(q, "battery", "power level", "charging", "battery status", "charge kitna hai", "battery kitni hai", "arc reactor power")) {
            return AiIntent.BatteryStatus
        }

        // 13. Time & Date
        if (containsAny(q, "what time", "current time", "samay", "kya time hua", "time batao", "aaj ki date", "today's date", "date kya hai")) {
            return AiIntent.TimeDate
        }

        // 14. Notes & Reminders
        if (q.startsWith("note ") || q.startsWith("take a note") || q.startsWith("note likho") || q.startsWith("remember") || q.startsWith("yaad rakhna")) {
            val content = q.removePrefix("take a note that")
                .removePrefix("take a note")
                .removePrefix("note likho")
                .removePrefix("note that")
                .removePrefix("note")
                .removePrefix("remember that")
                .removePrefix("remember")
                .removePrefix("yaad rakhna ki")
                .removePrefix("yaad rakhna")
                .trim()

            val title = if (content.length > 20) content.take(20) + "..." else content
            return AiIntent.SaveNote(
                title = if (title.isBlank()) "Quick Note" else title.replaceFirstChar { it.uppercase() },
                content = if (content.isBlank()) "Empty Note recorded by JARVIS" else content
            )
        }

        // 15. Smart Routines
        if (containsAny(q, "good morning", "morning brief", "shubh prabhat", "start my day")) {
            return AiIntent.RunSmartRoutine("MORNING_BRIEF")
        }
        if (containsAny(q, "focus mode", "activate focus", "study mode", "work mode")) {
            return AiIntent.RunSmartRoutine("FOCUS_MODE")
        }
        if (containsAny(q, "diagnostics", "system check", "security check", "security diagnostics", "scan system")) {
            return AiIntent.RunSmartRoutine("SECURITY_CHECK")
        }
        if (containsAny(q, "good night", "night protocol", "shubh ratri", "sleep mode")) {
            return AiIntent.RunSmartRoutine("NIGHT_MODE")
        }

        // 16. Web Search
        if (q.startsWith("search ") || q.startsWith("google ") || q.startsWith("dhoondo ")) {
            val queryText = q.removePrefix("search for")
                .removePrefix("search")
                .removePrefix("google")
                .removePrefix("dhoondo")
                .trim()
            if (queryText.isNotEmpty()) {
                return AiIntent.WebSearch(queryText)
            }
        }

        // 17. Security & Sandboxing Policies
        if (containsAny(q, "hack", "root device", "format phone", "install malicious", "delete system", "restart device")) {
            return AiIntent.Unsupported(
                rawQuery = query,
                reason = "Protocol denied, Sir. Android security and sandboxing policies prohibit unauthorized root or destructive operations."
            )
        }

        // 18. Conversational AI fallback
        return AiIntent.ConversationalAi(query)
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { keyword -> text.contains(keyword) }
    }
}
