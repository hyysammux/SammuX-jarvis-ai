package com.example.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log

sealed class WhatsAppActionResult {
    data class Success(val message: String, val recipient: String, val text: String?) : WhatsAppActionResult()
    data class ContactNotFound(val query: String, val explanation: String) : WhatsAppActionResult()
    data class AppNotInstalled(val message: String) : WhatsAppActionResult()
    data class VerificationRequired(val reason: String) : WhatsAppActionResult()
    data class Failed(val error: String) : WhatsAppActionResult()
}

class WhatsAppAutomationHandler(
    private val context: Context,
    private val contactActionHandler: ContactActionHandler
) {

    private val whatsappPackage = "com.whatsapp"

    fun isWhatsAppInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(whatsappPackage, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Sends a WhatsApp message to a given recipient (contact name or direct phone number).
     */
    fun sendWhatsAppMessage(
        recipientNameOrNumber: String,
        messageText: String,
        isVoiceVerified: Boolean
    ): WhatsAppActionResult {
        Log.d(TAG, "sendWhatsAppMessage to '$recipientNameOrNumber': '$messageText', verified=$isVoiceVerified")

        // 1. Voice Verification Guard
        if (!isVoiceVerified) {
            return WhatsAppActionResult.VerificationRequired(
                "Voice security verification failed, Sir. Messaging and communication controls are locked to unauthorized speakers."
            )
        }

        // 2. Check App Installation
        if (!isWhatsAppInstalled()) {
            return WhatsAppActionResult.AppNotInstalled(
                "WhatsApp application is not installed on this device, Sir. Communication cannot be dispatched."
            )
        }

        val cleanRecipient = recipientNameOrNumber.trim()
        val cleanMsg = messageText.trim()

        if (cleanRecipient.isBlank()) {
            return WhatsAppActionResult.Failed("No recipient specified for the WhatsApp message, Sir.")
        }

        // 3. Resolve Phone Number
        val isDirectNumber = cleanRecipient.replace(Regex("[+\\-\\s()]"), "").all { it.isDigit() } &&
                cleanRecipient.count { it.isDigit() } >= 7

        val targetPhone = if (isDirectNumber) {
            cleanRecipient.replace(Regex("[^0-9+]"), "")
        } else {
            val contactLookup = contactActionHandler.findContactDetails(cleanRecipient)
            if (contactLookup == null) {
                return WhatsAppActionResult.ContactNotFound(
                    query = cleanRecipient,
                    explanation = "I could not locate '$cleanRecipient' in your address book, Sir. Please confirm the contact name or provide the phone number directly."
                )
            }
            contactLookup.phoneNumber.replace(Regex("[^0-9+]"), "")
        }

        // Format phone number: Remove leading 0 and ensure country code if applicable
        val formattedPhone = if (targetPhone.startsWith("+")) {
            targetPhone.removePrefix("+")
        } else if (targetPhone.length == 10) {
            // Defaulting without prefix or national notation
            targetPhone
        } else {
            targetPhone
        }

        return try {
            val encodedMsg = Uri.encode(cleanMsg)
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedMsg")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(whatsappPackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                WhatsAppActionResult.Success(
                    message = "Dispatching WhatsApp message to $cleanRecipient: '$cleanMsg', Sir.",
                    recipient = cleanRecipient,
                    text = cleanMsg
                )
            } else {
                // Fallback general send intent
                val fallbackIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    setPackage(whatsappPackage)
                    putExtra(Intent.EXTRA_TEXT, cleanMsg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
                WhatsAppActionResult.Success(
                    message = "Opening WhatsApp composer for $cleanRecipient, Sir.",
                    recipient = cleanRecipient,
                    text = cleanMsg
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch WhatsApp send: ${e.message}", e)
            WhatsAppActionResult.Failed("Unable to transmit WhatsApp communication: ${e.message}")
        }
    }

    /**
     * Initiates a voice call to a contact via WhatsApp or system telephony fallback.
     */
    fun callContactWhatsApp(
        recipientNameOrNumber: String,
        isVoiceVerified: Boolean
    ): WhatsAppActionResult {
        if (!isVoiceVerified) {
            return WhatsAppActionResult.VerificationRequired(
                "Voice security verification failed, Sir. Calling protocols are locked."
            )
        }

        if (!isWhatsAppInstalled()) {
            return WhatsAppActionResult.AppNotInstalled(
                "WhatsApp is not installed on this device, Sir. Please use cellular calling."
            )
        }

        val cleanRecipient = recipientNameOrNumber.trim()
        val isDirectNumber = cleanRecipient.replace(Regex("[+\\-\\s()]"), "").all { it.isDigit() } &&
                cleanRecipient.count { it.isDigit() } >= 7

        val targetPhone = if (isDirectNumber) {
            cleanRecipient.replace(Regex("[^0-9+]"), "")
        } else {
            val contactLookup = contactActionHandler.findContactDetails(cleanRecipient)
                ?: return WhatsAppActionResult.ContactNotFound(
                    query = cleanRecipient,
                    explanation = "I could not locate '$cleanRecipient' in your address book, Sir."
                )
            contactLookup.phoneNumber.replace(Regex("[^0-9+]"), "")
        }

        val formattedPhone = targetPhone.removePrefix("+")

        return try {
            // WhatsApp opens contact chat where VoIP call can be initiated
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(whatsappPackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            WhatsAppActionResult.Success(
                message = "Opening WhatsApp conversation for $cleanRecipient to place your call, Sir.",
                recipient = cleanRecipient,
                text = null
            )
        } catch (e: Exception) {
            WhatsAppActionResult.Failed("Unable to open WhatsApp call channel: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "WhatsAppAutomation"
    }
}
