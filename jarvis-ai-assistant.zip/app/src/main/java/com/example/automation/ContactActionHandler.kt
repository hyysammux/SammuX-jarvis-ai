package com.example.automation

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log
import androidx.core.content.ContextCompat

data class ContactLookupResult(
    val name: String,
    val phoneNumber: String
)

sealed class ContactActionResult {
    data class Success(val message: String, val contactName: String, val phoneNumber: String) : ContactActionResult()
    data class ActionBlocked(val reason: String) : ContactActionResult()
    data class NotFound(val query: String, val explanation: String) : ContactActionResult()
}

class ContactActionHandler(private val context: Context) {

    /**
     * Executes phone call or dial action for contact name or raw phone number.
     */
    fun callContactOrNumber(target: String): ContactActionResult {
        val cleanTarget = target.trim()
        if (cleanTarget.isBlank()) {
            return ContactActionResult.ActionBlocked("No contact name or phone number was specified, Sir.")
        }

        // Check if target is directly a numeric phone number
        val isNumeric = cleanTarget.replace(Regex("[+\\-\\s()]"), "").all { it.isDigit() } &&
                cleanTarget.count { it.isDigit() } >= 3

        if (isNumeric) {
            return executeDialOrCall(cleanTarget, cleanTarget)
        }

        // Check READ_CONTACTS permission
        val hasContactPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasContactPermission) {
            return ContactActionResult.ActionBlocked(
                "Contacts permission has not been granted, Sir. Please authorize Contacts access in application settings to look up '$cleanTarget'."
            )
        }

        val lookup = findContactByName(cleanTarget)
            ?: return ContactActionResult.NotFound(
                query = cleanTarget,
                explanation = "I could not find any contact named '$cleanTarget' in your local address book, Sir. Please verify the contact name or dictate the number directly."
            )

        return executeDialOrCall(lookup.name, lookup.phoneNumber)
    }

    @SuppressLint("MissingPermission")
    private fun executeDialOrCall(displayName: String, phoneNumber: String): ContactActionResult {
        val hasCallPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val intent = if (hasCallPermission) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } else {
            // Fallback to Dialer intent which does not crash and works on all Android devices
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }

        return try {
            context.startActivity(intent)
            if (hasCallPermission) {
                ContactActionResult.Success(
                    message = "Initiating voice call to $displayName at $phoneNumber, Sir.",
                    contactName = displayName,
                    phoneNumber = phoneNumber
                )
            } else {
                ContactActionResult.Success(
                    message = "Opening dialer with $displayName at $phoneNumber, Sir. Direct placement requires Call Phone permission.",
                    contactName = displayName,
                    phoneNumber = phoneNumber
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to execute call intent: ${e.message}")
            ContactActionResult.ActionBlocked("Unable to initiate call for $displayName: ${e.message}")
        }
    }

    fun findContactDetails(queryName: String): ContactLookupResult? {
        return findContactByName(queryName)
    }

    private fun findContactByName(queryName: String): ContactLookupResult? {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$queryName%")

        try {
            context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (nameIdx != -1 && numberIdx != -1) {
                        val name = cursor.getString(nameIdx)
                        val number = cursor.getString(numberIdx)
                        return ContactLookupResult(name, number)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying contacts: ${e.message}")
        }
        return null
    }

    companion object {
        private const val TAG = "ContactActionHandler"
    }
}
