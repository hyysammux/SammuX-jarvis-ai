package com.example.automation

import com.example.data.JarvisRepository

class RoutineManager(
    private val deviceController: DeviceController,
    private val repository: JarvisRepository
) {

    suspend fun executeRoutine(actionType: String): String {
        return when (actionType) {
            "MORNING_BRIEF" -> {
                val timeStr = deviceController.getCurrentTimeAndDate()
                val batteryStr = deviceController.getBatteryStatus()
                "Good morning, Sir. $timeStr $batteryStr All systems operating within normal parameters. Ready for instructions."
            }
            "FOCUS_MODE" -> {
                deviceController.adjustVolume(VolumeDirection.MUTE)
                deviceController.toggleFlashlight(false)
                "Focus protocol engaged, Sir. Media silenced and external indicators disabled. Do not disturb mode active."
            }
            "SECURITY_CHECK" -> {
                val battery = deviceController.getBatteryStatus()
                "Security Diagnostics complete, Sir. Biometric voice vault is encrypted with AES-256 GCM. $battery Core integrity at 100%."
            }
            "NIGHT_MODE" -> {
                deviceController.toggleFlashlight(false)
                deviceController.adjustVolume(VolumeDirection.MUTE)
                "Night protocol activated. Systems transitioning to low-power standby. Rest well, Sir."
            }
            else -> {
                "Routine protocol '$actionType' completed successfully, Sir."
            }
        }
    }
}
