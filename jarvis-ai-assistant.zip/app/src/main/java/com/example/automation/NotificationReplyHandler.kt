package com.example.automation

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.notifications.CapturedNotification
import com.example.notifications.JarvisNotificationListener

data class PendingNotificationDraft(
    val notificationKey: String,
    val appName: String,
    val senderName: String,
    val draftText: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed class NotificationDraftResult {
    data class ReadComplete(val speech: String, val latestNotification: CapturedNotification?) : NotificationDraftResult()
    data class DraftCreated(val speech: String, val draft: PendingNotificationDraft) : NotificationDraftResult()
    data class ReplySent(val speech: String, val recipient: String) : NotificationDraftResult()
    data class DraftCancelled(val speech: String) : NotificationDraftResult()
    data class UnsupportedInlineReply(val speech: String, val packageName: String) : NotificationDraftResult()
    data class NoTargetNotification(val speech: String) : NotificationDraftResult()
}

class NotificationReplyHandler(private val context: Context) {

    private var activeDraft: PendingNotificationDraft? = null

    fun getActiveDraft(): PendingNotificationDraft? = activeDraft

    /**
     * Reads recent notifications and formats the interactive prompt:
     * "क्या मैं रिप्लाई ड्राफ्ट करूँ? Should I draft a reply, Sir?"
     */
    fun readNotificationsAndPrompt(): NotificationDraftResult {
        if (!JarvisNotificationListener.isNotificationAccessGranted(context)) {
            return NotificationDraftResult.ReadComplete(
                speech = "Notification access is not enabled in Android settings, Sir. Please grant Notification Listener access.",
                latestNotification = null
            )
        }

        val notifications = JarvisNotificationListener.getRecentNotifications()
        if (notifications.isEmpty()) {
            return NotificationDraftResult.ReadComplete(
                speech = "You have no active notifications at present, Sir.",
                latestNotification = null
            )
        }

        val speechSummary = JarvisNotificationListener.formatNotificationsForSpeech(context)
        val latest = notifications.firstOrNull()

        val promptSuffix = if (latest != null) {
            " क्या मैं रिप्लाई ड्राफ्ट करूँ? Should I draft a reply to ${latest.appName}, Sir?"
        } else {
            ""
        }

        return NotificationDraftResult.ReadComplete(
            speech = "$speechSummary$promptSuffix",
            latestNotification = latest
        )
    }

    /**
     * Prepares a text reply draft for the specified or latest notification.
     */
    fun prepareDraft(dictatedMessage: String, targetAppNameOrSender: String? = null): NotificationDraftResult {
        val cleanMsg = dictatedMessage.trim()
        if (cleanMsg.isBlank()) {
            return NotificationDraftResult.NoTargetNotification("The draft message was empty, Sir. What would you like me to say?")
        }

        val notifications = JarvisNotificationListener.getRecentNotifications()
        if (notifications.isEmpty()) {
            return NotificationDraftResult.NoTargetNotification("There are no active notifications to reply to, Sir.")
        }

        val target = if (!targetAppNameOrSender.isNullOrBlank()) {
            val cleanFilter = targetAppNameOrSender.lowercase()
            notifications.firstOrNull {
                it.appName.lowercase().contains(cleanFilter) || it.title.lowercase().contains(cleanFilter)
            } ?: notifications.first()
        } else {
            notifications.first()
        }

        val draft = PendingNotificationDraft(
            notificationKey = target.notificationKey,
            appName = target.appName,
            senderName = target.title.ifBlank { target.appName },
            draftText = cleanMsg
        )
        activeDraft = draft

        return NotificationDraftResult.DraftCreated(
            speech = "Draft prepared for ${draft.senderName} on ${draft.appName}: '${draft.draftText}'. Confirm sending, Sir?",
            draft = draft
        )
    }

    /**
     * Confirms and sends the active draft using Android RemoteInput.
     */
    fun confirmAndSend(): NotificationDraftResult {
        val draft = activeDraft
            ?: return NotificationDraftResult.NoTargetNotification("No pending draft exists to send, Sir.")

        val success = JarvisNotificationListener.sendInlineReply(
            context = context,
            notificationKey = draft.notificationKey,
            replyText = draft.draftText
        )

        activeDraft = null

        return if (success) {
            NotificationDraftResult.ReplySent(
                speech = "Reply transmitted to ${draft.senderName} successfully, Sir.",
                recipient = draft.senderName
            )
        } else {
            // Find package to open directly if inline RemoteInput is unavailable
            val recent = JarvisNotificationListener.getRecentNotifications()
            val notif = recent.firstOrNull { it.notificationKey == draft.notificationKey }
            val pkg = notif?.packageName.orEmpty()

            if (pkg.isNotBlank()) {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(launchIntent)
                } catch (e: Exception) {
                    Log.e(TAG, "Could not launch package $pkg: ${e.message}")
                }
            }

            NotificationDraftResult.UnsupportedInlineReply(
                speech = "Direct inline reply is not supported by ${draft.appName}'s notification. Opening the application for you directly, Sir.",
                packageName = pkg
            )
        }
    }

    /**
     * Cancels active draft, giving full control back to user.
     */
    fun cancelDraft(): NotificationDraftResult {
        activeDraft = null
        return NotificationDraftResult.DraftCancelled("Draft cancelled, Sir. Message will not be sent.")
    }

    companion object {
        private const val TAG = "NotificationReplyHandler"
    }
}
