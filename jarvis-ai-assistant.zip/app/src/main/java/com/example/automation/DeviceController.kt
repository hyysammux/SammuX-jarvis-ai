package com.example.automation

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import com.example.notifications.JarvisNotificationListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeviceController(private val context: Context) {

    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    }

    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    private var isTorchOn: Boolean = false

    fun toggleFlashlight(enable: Boolean? = null): Result<String> {
        val manager = cameraManager ?: return Result.failure(Exception("Camera manager unavailable on this device"))
        return try {
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(
                    android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE
                ) == true
            } ?: return Result.failure(Exception("No camera flash hardware detected on this device, Sir."))

            val targetState = enable ?: !isTorchOn
            manager.setTorchMode(cameraId, targetState)
            isTorchOn = targetState
            val status = if (targetState) "engaged and illuminating" else "powered down"
            Result.success("Flashlight has been $status, Sir.")
        } catch (e: CameraAccessException) {
            Log.e(TAG, "Camera flash access exception: ${e.message}")
            Result.failure(Exception("Flash hardware is currently locked by another process: ${e.message}"))
        } catch (e: Exception) {
            Result.failure(Exception("Unable to manipulate flashlight: ${e.message}"))
        }
    }

    fun adjustVolume(direction: VolumeDirection): Result<String> {
        val audio = audioManager ?: return Result.failure(Exception("Audio manager is currently unavailable"))
        return try {
            when (direction) {
                VolumeDirection.UP -> {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    Result.success("Media volume increased by one level, Sir.")
                }
                VolumeDirection.DOWN -> {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    Result.success("Media volume lowered by one level, Sir.")
                }
                VolumeDirection.MUTE -> {
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                    Result.success("Audio output has been muted, Sir.")
                }
                VolumeDirection.MAX -> {
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
                    Result.success("Audio output set to maximum output capacity, Sir.")
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception("Failed to adjust volume: ${e.message}"))
        }
    }

    fun getBatteryStatus(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val isCharging = bm?.isCharging == true
        val chargeStatus = if (isCharging) "currently charging" else "running on internal cell"
        return if (level >= 0) {
            "Internal power cells are at $level percent capacity, and $chargeStatus, Sir."
        } else {
            "Power telemetry is currently reporting normal nominal levels, Sir."
        }
    }

    fun getCurrentTimeAndDate(): String {
        val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
        val now = Date()
        return "The time is currently ${timeFormat.format(now)}, on ${dateFormat.format(now)}, Sir."
    }

    fun launchApplication(target: AppTarget): Result<String> {
        val pm = context.packageManager
        val intent = when (target) {
            AppTarget.YOUTUBE -> pm.getLaunchIntentForPackage("com.google.android.youtube")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            AppTarget.INSTAGRAM -> pm.getLaunchIntentForPackage("com.instagram.android")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com"))
            AppTarget.SPOTIFY -> pm.getLaunchIntentForPackage("com.spotify.music")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com"))
            AppTarget.WHATSAPP -> pm.getLaunchIntentForPackage("com.whatsapp")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com"))
            AppTarget.CAMERA -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            AppTarget.SETTINGS -> Intent(Settings.ACTION_SETTINGS)
            AppTarget.BROWSER -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            AppTarget.MAPS -> pm.getLaunchIntentForPackage("com.google.android.apps.maps")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=current+location"))
            AppTarget.PHONE -> Intent(Intent.ACTION_DIAL)
            AppTarget.SNAPCHAT -> pm.getLaunchIntentForPackage("com.snapchat.android")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.snapchat.com"))
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            Result.success("Opening ${target.displayName}, Sir.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch app: ${e.message}")
            Result.failure(Exception("Unable to open ${target.displayName}. Application may not be installed on this device."))
        }
    }

    /**
     * Searches and plays specific content on YouTube.
     */
    fun searchYouTube(query: String): Result<String> {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) {
            return launchApplication(AppTarget.YOUTUBE)
        }

        val pm = context.packageManager
        val intent = try {
            val appIntent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", cleanQuery)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (appIntent.resolveActivity(pm) != null) {
                appIntent
            } else {
                val encoded = Uri.encode(cleanQuery)
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        } catch (e: Exception) {
            val encoded = Uri.encode(cleanQuery)
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }

        return try {
            context.startActivity(intent)
            Result.success("Searching and playing '$cleanQuery' on YouTube, Sir.")
        } catch (e: Exception) {
            Result.failure(Exception("Unable to launch YouTube query: ${e.message}"))
        }
    }

    /**
     * Opens Instagram, optionally navigating to a user profile or explore page.
     */
    fun openInstagram(profileOrQuery: String? = null): Result<String> {
        val pm = context.packageManager
        val clean = profileOrQuery?.trim()?.removePrefix("@")

        val intent = if (!clean.isNullOrBlank()) {
            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/$clean")).apply {
                setPackage("com.instagram.android")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (appIntent.resolveActivity(pm) != null) {
                appIntent
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/$clean")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        } else {
            pm.getLaunchIntentForPackage("com.instagram.android")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com"))
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            val msg = if (!clean.isNullOrBlank()) "Navigating to Instagram profile for @$clean, Sir." else "Opening Instagram, Sir."
            Result.success(msg)
        } catch (e: Exception) {
            Result.failure(Exception("Unable to open Instagram: ${e.message}"))
        }
    }

    /**
     * Directly opens developer Sammu's Instagram profile:
     * https://www.instagram.com/hyy_sammu.x?stkn=MXZjb2hydTNsc3p3NQ==
     */
    fun openDeveloperInstagram(): Result<String> {
        val url = "https://www.instagram.com/hyy_sammu.x?stkn=MXZjb2hydTNsc3p3NQ=="
        val pm = context.packageManager
        val intent = try {
            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage("com.instagram.android")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (appIntent.resolveActivity(pm) != null) {
                appIntent
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        } catch (e: Exception) {
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }

        return try {
            context.startActivity(intent)
            Result.success("Opening developer Sammu's Instagram profile (@hyy_sammu.x), Sir.")
        } catch (e: Exception) {
            Result.failure(Exception("Unable to open Instagram profile: ${e.message}"))
        }
    }

    /**
     * Dynamically finds and launches any installed app by user-dictated name.
     * Never guesses: if the app is missing, explicitly informs the user.
     */
    fun launchDynamicApp(appName: String): Result<String> {
        val cleanName = appName.trim().lowercase(Locale.ROOT)
        val pm = context.packageManager

        try {
            val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in installed) {
                val label = pm.getApplicationLabel(app).toString().lowercase(Locale.ROOT)
                if (label == cleanName || label.contains(cleanName) || cleanName.contains(label)) {
                    val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        val realLabel = pm.getApplicationLabel(app).toString()
                        return Result.success("Opening $realLabel, Sir.")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error looking up dynamic app: ${e.message}")
        }

        return Result.failure(
            Exception("Application '$appName' was not found installed on this device, Sir. Would you like me to search for it on Google Play or the web?")
        )
    }

    fun openWebSearch(query: String): Result<String> {
        return try {
            val encoded = Uri.encode(query)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("Searching for '$query' on the web, Sir.")
        } catch (e: Exception) {
            Result.failure(Exception("Could not launch search browser: ${e.message}"))
        }
    }

    fun readNotifications(): String {
        return JarvisNotificationListener.formatNotificationsForSpeech(context)
    }

    companion object {
        private const val TAG = "DeviceController"
    }
}

enum class VolumeDirection { UP, DOWN, MUTE, MAX }

enum class AppTarget(val displayName: String) {
    YOUTUBE("YouTube"),
    INSTAGRAM("Instagram"),
    SPOTIFY("Spotify"),
    CAMERA("Camera"),
    WHATSAPP("WhatsApp"),
    SETTINGS("Settings"),
    BROWSER("Browser"),
    MAPS("Maps"),
    PHONE("Phone"),
    SNAPCHAT("Snapchat")
}
