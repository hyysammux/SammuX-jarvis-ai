package com.example.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.util.Log
import android.view.KeyEvent
import com.example.accessibility.JarvisAccessibilityService

enum class YouTubeSubAction {
    OPEN,
    SEARCH,
    PLAY_FIRST,
    PAUSE_RESUME,
    NEXT_VIDEO,
    SUBSCRIBE
}

sealed class YouTubeActionResult {
    data class Success(val spokenResponse: String, val visualDetails: String) : YouTubeActionResult()
    data class PolicyExplanation(val explanation: String) : YouTubeActionResult()
    data class Failed(val error: String) : YouTubeActionResult()
}

class YouTubeAutomationHandler(private val context: Context) {

    private val youtubePackage = "com.google.android.youtube"

    fun isYouTubeInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(youtubePackage, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun executeAction(action: YouTubeSubAction, param: String? = null): YouTubeActionResult {
        Log.d(TAG, "executeAction: $action, param: $param")
        val pm = context.packageManager

        return try {
            when (action) {
                YouTubeSubAction.OPEN -> {
                    val intent = pm.getLaunchIntentForPackage(youtubePackage)
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    YouTubeActionResult.Success(
                        spokenResponse = "Opening YouTube, Sir.",
                        visualDetails = "Launched YouTube Application"
                    )
                }

                YouTubeSubAction.SEARCH -> {
                    val query = param?.trim().orEmpty()
                    if (query.isBlank()) {
                        executeAction(YouTubeSubAction.OPEN)
                    } else {
                        val appIntent = Intent(Intent.ACTION_SEARCH).apply {
                            setPackage(youtubePackage)
                            putExtra("query", query)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        if (appIntent.resolveActivity(pm) != null) {
                            context.startActivity(appIntent)
                        } else {
                            val webIntent = Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
                            ).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(webIntent)
                        }

                        YouTubeActionResult.Success(
                            spokenResponse = "Searching for '$query' on YouTube, Sir.",
                            visualDetails = "YouTube Search Query: '$query'"
                        )
                    }
                }

                YouTubeSubAction.PLAY_FIRST -> {
                    val query = param?.trim().orEmpty()
                    val targetQuery = if (query.isBlank()) "popular music videos" else query

                    val appIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(youtubePackage)
                        putExtra("query", targetQuery)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    if (appIntent.resolveActivity(pm) != null) {
                        context.startActivity(appIntent)
                    } else {
                        val webIntent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(targetQuery)}")
                        ).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webIntent)
                    }

                    // If Accessibility Service is enabled, attempt to click the first video item
                    if (JarvisAccessibilityService.isServiceRunning()) {
                        JarvisAccessibilityService.findAndClickByContentDescription("Play video")
                    }

                    YouTubeActionResult.Success(
                        spokenResponse = "Playing '$targetQuery' on YouTube, Sir.",
                        visualDetails = "Playing content: '$targetQuery'"
                    )
                }

                YouTubeSubAction.PAUSE_RESUME -> {
                    val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (audioManager != null) {
                        val downEvent = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                        val upEvent = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                        audioManager.dispatchMediaKeyEvent(downEvent)
                        audioManager.dispatchMediaKeyEvent(upEvent)

                        YouTubeActionResult.Success(
                            spokenResponse = "Media playback toggled, Sir.",
                            visualDetails = "Dispatched KEYCODE_MEDIA_PLAY_PAUSE"
                        )
                    } else {
                        YouTubeActionResult.Failed("Audio media controller is currently unavailable.")
                    }
                }

                YouTubeSubAction.NEXT_VIDEO -> {
                    val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (audioManager != null) {
                        val downEvent = KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT)
                        val upEvent = KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_NEXT)
                        audioManager.dispatchMediaKeyEvent(downEvent)
                        audioManager.dispatchMediaKeyEvent(upEvent)

                        YouTubeActionResult.Success(
                            spokenResponse = "Skipping to next track or video, Sir.",
                            visualDetails = "Dispatched KEYCODE_MEDIA_NEXT"
                        )
                    } else {
                        YouTubeActionResult.Failed("Audio media controller is currently unavailable.")
                    }
                }

                YouTubeSubAction.SUBSCRIBE -> {
                    // Transparent Android policy check: Background subscribing without user tap violates Google Play security policies
                    val clicked = if (JarvisAccessibilityService.isServiceRunning()) {
                        JarvisAccessibilityService.findAndClickByText("Subscribe") ||
                                JarvisAccessibilityService.findAndClickByContentDescription("Subscribe")
                    } else {
                        false
                    }

                    if (clicked) {
                        YouTubeActionResult.Success(
                            spokenResponse = "Channel subscription action engaged via Accessibility assistance, Sir.",
                            visualDetails = "Subscription Button Clicked"
                        )
                    } else {
                        YouTubeActionResult.PolicyExplanation(
                            "Under Google Play safety policies, automated channel subscription requires direct user consent. I have focused the YouTube window so you can tap Subscribe directly, Sir."
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing YouTube automation: ${e.message}", e)
            YouTubeActionResult.Failed("YouTube automation encountered an issue: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "YouTubeAutomation"
    }
}
