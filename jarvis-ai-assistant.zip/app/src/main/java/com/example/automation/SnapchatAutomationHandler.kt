package com.example.automation

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.util.Log
import com.example.accessibility.JarvisAccessibilityService

enum class SnapchatSubAction {
    OPEN_APP,
    OPEN_CHATS,
    SEARCH_CONTACT,
    OPEN_STORIES,
    OPEN_CAMERA,
    OPEN_PROFILE,
    SETTINGS,
    REPLY_NOTIFICATION,
    RESTRICTED_ACTION
}

sealed class SnapchatActionResult {
    data class Success(val spokenResponse: String, val visualDetails: String) : SnapchatActionResult()
    data class AppNotInstalled(val message: String) : SnapchatActionResult()
    data class PolicyRestriction(val explanation: String) : SnapchatActionResult()
    data class ActionFailed(val error: String) : SnapchatActionResult()
}

class SnapchatAutomationHandler(private val context: Context) {

    private val snapchatPackage = "com.snapchat.android"

    fun isSnapchatInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(snapchatPackage, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun executeAction(action: SnapchatSubAction, param: String? = null): SnapchatActionResult {
        Log.d(TAG, "Executing Snapchat action: $action with param: $param")

        // Handle impossible or security-violating requests with clear explanations
        if (action == SnapchatSubAction.RESTRICTED_ACTION) {
            val reason = param ?: "private message scraping"
            return SnapchatActionResult.PolicyRestriction(
                "Protocol restricted, Sir. Android application sandboxing and Snapchat's end-to-end encryption prohibit third-party apps from intercepting private snaps, capturing unnotified screenshots, or accessing raw friend databases. I can only navigate supported screens on your behalf."
            )
        }

        if (!isSnapchatInstalled()) {
            return SnapchatActionResult.AppNotInstalled(
                "Snapchat is not installed on this device, Sir. Would you like me to open the Google Play Store for installation?"
            )
        }

        val pm = context.packageManager

        return try {
            when (action) {
                SnapchatSubAction.OPEN_APP -> {
                    val intent = pm.getLaunchIntentForPackage(snapchatPackage)
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.snapchat.com"))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    SnapchatActionResult.Success(
                        spokenResponse = "Opening Snapchat, Sir.",
                        visualDetails = "Launched Snapchat application"
                    )
                }

                SnapchatSubAction.OPEN_CHATS -> {
                    // Deep link to Chat screen or open and navigate via accessibility
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("snapchat://chat")).apply {
                        setPackage(snapchatPackage)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(pm) != null) {
                        context.startActivity(intent)
                    } else {
                        val fallback = pm.getLaunchIntentForPackage(snapchatPackage)
                        fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(fallback)
                    }

                    // If Accessibility is active, attempt to focus chat pane
                    if (JarvisAccessibilityService.isServiceRunning()) {
                        JarvisAccessibilityService.findAndClickByText("Chat")
                    }

                    SnapchatActionResult.Success(
                        spokenResponse = "Navigating to your Snapchat Chats feed, Sir.",
                        visualDetails = "Opened Snapchat • Chats Navigation"
                    )
                }

                SnapchatSubAction.SEARCH_CONTACT -> {
                    val contactQuery = param?.trim().orEmpty().removePrefix("@")
                    if (contactQuery.isBlank()) {
                        executeAction(SnapchatSubAction.OPEN_CHATS)
                    } else {
                        // Official Snapchat add/search deep link
                        val addUri = Uri.parse("https://www.snapchat.com/add/$contactQuery")
                        val intent = Intent(Intent.ACTION_VIEW, addUri).apply {
                            setPackage(snapchatPackage)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }

                        if (intent.resolveActivity(pm) != null) {
                            context.startActivity(intent)
                        } else {
                            val webIntent = Intent(Intent.ACTION_VIEW, addUri).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(webIntent)
                        }

                        SnapchatActionResult.Success(
                            spokenResponse = "Searching for Snapchat user '$contactQuery', Sir.",
                            visualDetails = "Snapchat User Search: @$contactQuery"
                        )
                    }
                }

                SnapchatSubAction.OPEN_STORIES -> {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("snapchat://stories")).apply {
                        setPackage(snapchatPackage)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(pm) != null) {
                        context.startActivity(intent)
                    } else {
                        val fallback = pm.getLaunchIntentForPackage(snapchatPackage)
                        fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(fallback)
                    }

                    if (JarvisAccessibilityService.isServiceRunning()) {
                        JarvisAccessibilityService.findAndClickByText("Stories")
                    }

                    SnapchatActionResult.Success(
                        spokenResponse = "Opening Snapchat Stories and Discover stream, Sir.",
                        visualDetails = "Opened Snapchat • Stories Screen"
                    )
                }

                SnapchatSubAction.OPEN_CAMERA -> {
                    // Snapchat opens to camera by default, or use camera deep link
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("snapchat://camera")).apply {
                        setPackage(snapchatPackage)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(pm) != null) {
                        context.startActivity(intent)
                    } else {
                        val fallback = pm.getLaunchIntentForPackage(snapchatPackage)
                        fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(fallback)
                    }

                    SnapchatActionResult.Success(
                        spokenResponse = "Opening Snapchat Camera viewfinder, Sir.",
                        visualDetails = "Snapchat Camera Viewfinder Active"
                    )
                }

                SnapchatSubAction.OPEN_PROFILE -> {
                    val user = param?.trim()?.removePrefix("@")
                    val intent = if (!user.isNullOrBlank()) {
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.snapchat.com/add/$user")).apply {
                            setPackage(snapchatPackage)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    } else {
                        Intent(Intent.ACTION_VIEW, Uri.parse("snapchat://profile")).apply {
                            setPackage(snapchatPackage)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    }

                    if (intent.resolveActivity(pm) != null) {
                        context.startActivity(intent)
                    } else {
                        val fallback = pm.getLaunchIntentForPackage(snapchatPackage)
                        fallback?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(fallback)
                    }

                    val spoken = if (!user.isNullOrBlank()) "Opening Snapchat profile for @$user, Sir." else "Opening your Snapchat profile, Sir."
                    SnapchatActionResult.Success(spokenResponse = spoken, visualDetails = "Snapchat Profile: ${user ?: "Self"}")
                }

                SnapchatSubAction.SETTINGS -> {
                    // Open Snapchat settings or App Info settings if deep link not handled
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("snapchat://settings")).apply {
                        setPackage(snapchatPackage)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(pm) != null) {
                        context.startActivity(intent)
                        SnapchatActionResult.Success(
                            spokenResponse = "Navigating to Snapchat application settings, Sir.",
                            visualDetails = "Snapchat In-App Settings"
                        )
                    } else {
                        val appInfoIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:$snapchatPackage")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(appInfoIntent)
                        SnapchatActionResult.Success(
                            spokenResponse = "Opening system application settings for Snapchat, Sir.",
                            visualDetails = "System Settings • Snapchat"
                        )
                    }
                }

                SnapchatSubAction.REPLY_NOTIFICATION -> {
                    SnapchatActionResult.Success(
                        spokenResponse = "Forwarding to notification handler for active Snapchat alerts, Sir.",
                        visualDetails = "Notification Relay • Snapchat"
                    )
                }

                SnapchatSubAction.RESTRICTED_ACTION -> {
                    SnapchatActionResult.PolicyRestriction("Action prohibited by OS policy.")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing Snapchat action: ${e.message}", e)
            SnapchatActionResult.ActionFailed("Encountered unexpected error opening Snapchat: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "SnapchatAutomation"
    }
}
