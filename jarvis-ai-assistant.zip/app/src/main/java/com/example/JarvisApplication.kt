package com.example

import android.app.Application
import com.example.data.JarvisDatabase
import com.example.data.JarvisRepository
import com.example.notifications.JarvisNotificationManager
import com.example.security.SecureStorageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class JarvisApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database by lazy { JarvisDatabase.getDatabase(this) }
    val repository by lazy { JarvisRepository(database.jarvisDao()) }
    val secureStorage by lazy { SecureStorageManager(this) }
    val notificationManager by lazy { JarvisNotificationManager(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this

        applicationScope.launch {
            repository.ensureDefaultRoutines()
        }
    }

    companion object {
        lateinit var instance: JarvisApplication
            private set
    }
}
