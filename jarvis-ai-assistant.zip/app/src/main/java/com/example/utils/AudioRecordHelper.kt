package com.example.utils

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import com.example.voice.AudioFeatureExtractor
import com.example.voice.AudioFeatures
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AudioRecordHelper {

    private const val TAG = "AudioRecordHelper"
    private const val SAMPLE_RATE = 16000
    private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
    private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT

    /**
     * Records audio for durationMs and extracts acoustic features for voice enrollment.
     */
    @SuppressLint("MissingPermission")
    suspend fun recordSampleForEnrollment(
        durationMs: Long = 2800L,
        onAmplitudeChanged: (Float) -> Unit = {}
    ): AudioFeatures? = withContext(Dispatchers.IO) {
        val bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (bufferSize <= 0) {
            Log.e(TAG, "Invalid buffer size for AudioRecord")
            return@withContext null
        }

        var recorder: AudioRecord? = null
        try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize * 2
            )

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord not initialized")
                return@withContext null
            }

            val totalSamples = ((SAMPLE_RATE * durationMs) / 1000).toInt()
            val recordedData = ShortArray(totalSamples)
            var samplesRead = 0
            val readBuffer = ShortArray(bufferSize)

            recorder.startRecording()

            val startTime = System.currentTimeMillis()
            while (samplesRead < totalSamples && (System.currentTimeMillis() - startTime) < (durationMs + 500)) {
                val read = recorder.read(readBuffer, 0, (totalSamples - samplesRead).coerceAtMost(bufferSize))
                if (read > 0) {
                    System.arraycopy(readBuffer, 0, recordedData, samplesRead, read)
                    samplesRead += read

                    // Calculate instantaneous amplitude
                    var sum = 0.0
                    for (i in 0 until read) {
                        sum += Math.abs(readBuffer[i].toInt())
                    }
                    val avgAmp = (sum / (read * Short.MAX_VALUE)).toFloat().coerceIn(0f, 1f)
                    onAmplitudeChanged(avgAmp)
                }
            }

            recorder.stop()
            val finalData = if (samplesRead == totalSamples) recordedData else recordedData.copyOf(samplesRead)
            AudioFeatureExtractor.extractFeatures(finalData)
        } catch (e: Exception) {
            Log.e(TAG, "Error recording enrollment sample: ${e.message}")
            null
        } finally {
            try {
                recorder?.release()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}
